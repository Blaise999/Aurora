'use client';

const labels = ['Genesis', 'Myth', 'Future'];

export default function HeroLabels({ active = 0, onSwitch }) {
  return (
    <div className="flex items-center justify-center gap-3 mt-8">
      {labels.map((label, i) => (
        <button
          key={label}
          onClick={() => onSwitch?.(i)}
          className={`
            group flex items-center gap-2 px-4 py-2 rounded-pill text-sm font-medium
            transition-all duration-400 ease-out
            ${i === active
              ? 'bg-white/[0.08] text-text border border-accent/20 shadow-glow'
              : 'text-muted-dim hover:text-muted border border-transparent hover:border-white/[0.06]'
            }
          `}
        >
          <span className={`w-1.5 h-1.5 rounded-full transition-colors duration-300 ${
            i === active ? 'bg-accent' : 'bg-muted-dim group-hover:bg-muted'
          }`} />
          {label}
        </button>
      ))}
    </div>
  );
}
