'use client';
import { useState } from 'react';
import { Play } from 'lucide-react';

export default function NFTMedia({ src, alt = 'NFT', className = '', aspect = 'square', hasVideo = false }) {
  const [loaded, setLoaded] = useState(false);
  const isGradient = src?.startsWith('linear-gradient') || src?.startsWith('radial-gradient');

  const aspectClasses = {
    square: 'aspect-square',
    portrait: 'aspect-[3/4]',
    wide: 'aspect-[4/3]',
  };

  return (
    <div className={`relative overflow-hidden bg-surface2 ${aspectClasses[aspect]} ${className}`}>
      {isGradient ? (
        // Legacy gradient support
        <div className="absolute inset-0" style={{ background: src }} />
      ) : (
        <>
          {!loaded && <div className="absolute inset-0 skeleton-pulse" />}
          <img
            src={src}
            alt={alt}
            className={`w-full h-full object-cover transition-opacity duration-500 ${loaded ? 'opacity-100' : 'opacity-0'}`}
            onLoad={() => setLoaded(true)}
            loading="lazy"
          />
        </>
      )}

      {hasVideo && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/20">
          <div className="w-12 h-12 rounded-full glass flex items-center justify-center backdrop-blur-sm">
            <Play size={18} className="text-text ml-0.5" />
          </div>
        </div>
      )}

      {/* Bottom fade for overlaid text */}
      <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-black/30 to-transparent" />
    </div>
  );
}
