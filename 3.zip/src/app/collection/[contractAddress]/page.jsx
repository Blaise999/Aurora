'use client';

import { useParams } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import PageShell from '@/components/layout/PageShell';
import NFTGridCollection from '@/components/nft/NFTGridCollection';

export default function CollectionPage() {
  const params = useParams();
  const contractAddress = params?.contractAddress || '';

  return (
    <PageShell>
      <div className="max-w-[1400px] mx-auto px-6 md:px-8 py-8">
        <div className="mb-8">
          <Link
            href="/explore"
            className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-accent transition-colors mb-4"
          >
            <ArrowLeft size={14} /> Back to Explore
          </Link>
          <h1 className="font-display text-3xl font-bold text-text">
            Collection
          </h1>
          <p className="text-xs text-muted-dim font-mono mt-2 truncate max-w-md">
            {contractAddress}
          </p>
        </div>
        <NFTGridCollection contractAddress={contractAddress} />
      </div>
    </PageShell>
  );
}
