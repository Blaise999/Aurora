'use client';
import PageShell from '@/components/layout/PageShell';
import MintPanel from '@/components/mint/MintPanel';
import Badge from '@/components/ui/Badge';
import { mintStats } from '@/lib/mock/collections';
import { heroNFTs } from '@/lib/mock/nfts';

export default function MintPage() {
  return (
    <PageShell>
      <div className="max-w-[1400px] mx-auto px-6 md:px-8 py-8">
        {/* Header */}
        <div className="mb-10">
          <h1 className="font-display text-4xl font-bold text-text">Mint</h1>
          <p className="text-sm text-muted mt-2">Secure your piece from the Ethereal Voids collection</p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Left: Collection Preview */}
          <div className="lg:col-span-3 space-y-6">
            {/* Hero preview */}
            <div className="glass-card rounded-card overflow-hidden">
              <div className="aspect-[16/9] w-full relative overflow-hidden">
                <img
                  src="/pictures/mint-hero.svg"
                  alt="Ethereal Voids Collection"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/40 to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <Badge color="success" dot className="mb-3">Minting Live</Badge>
                  <h2 className="font-display text-2xl font-bold text-text">Ethereal Voids</h2>
                  <p className="text-sm text-muted mt-1">A generative collection of 10,000 unique digital artifacts</p>
                </div>
              </div>
            </div>

            {/* Preview grid */}
            <div className="grid grid-cols-3 gap-3">
              {heroNFTs.map((nft, i) => (
                <div key={i} className="glass-card rounded-card overflow-hidden">
                  <div className="aspect-square overflow-hidden">
                    <img
                      src={nft.normalized_metadata?.image}
                      alt={nft.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-3">
                    <p className="text-xs text-muted truncate">{nft.name}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Collection info */}
            <div className="glass-card rounded-card p-6 space-y-4">
              <h3 className="font-display font-semibold text-text">About the Collection</h3>
              <p className="text-sm text-muted leading-relaxed">
                Ethereal Voids is a curated collection of 10,000 algorithmically generated digital artifacts.
                Each piece features unique trait combinations spanning six categories, with provenance
                permanently recorded on the Ethereum blockchain. The collection explores themes of
                cosmic emptiness and digital transcendence through generative art.
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-border-light">
                <div>
                  <p className="text-xs text-muted-dim">Items</p>
                  <p className="text-lg font-display font-semibold text-text">10,000</p>
                </div>
                <div>
                  <p className="text-xs text-muted-dim">Owners</p>
                  <p className="text-lg font-display font-semibold text-text">4,821</p>
                </div>
                <div>
                  <p className="text-xs text-muted-dim">Floor</p>
                  <p className="text-lg font-display font-semibold text-text">0.42 ETH</p>
                </div>
                <div>
                  <p className="text-xs text-muted-dim">Volume</p>
                  <p className="text-lg font-display font-semibold text-text">1,247 ETH</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Mint Panel */}
          <div className="lg:col-span-2">
            <div className="lg:sticky lg:top-24">
              <MintPanel stats={mintStats} />
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
