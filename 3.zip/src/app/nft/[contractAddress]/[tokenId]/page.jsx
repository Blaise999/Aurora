'use client';

import { useParams } from 'next/navigation';
import { useEffect, useState, useCallback } from 'react';
import {
  ExternalLink,
  Heart,
  Share2,
  ArrowLeft,
  AlertCircle,
} from 'lucide-react';
import Link from 'next/link';
import PageShell from '@/components/layout/PageShell';
import NFTMedia from '@/components/nft/NFTMedia';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import Skeleton from '@/components/ui/Skeleton';

/* ── ipfs helper (same logic as server) ── */
function ipfs(url) {
  if (!url) return undefined;
  if (url.startsWith('ipfs://'))
    return url.replace('ipfs://', 'https://ipfs.io/ipfs/');
  return url;
}

export default function NFTDetailPage() {
  const params = useParams();
  const contractAddress = params?.contractAddress || '';
  const tokenId = params?.tokenId || '';

  const [nft, setNft] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchMetadata = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const url = new URL('/api/nft/metadata', window.location.origin);
      url.searchParams.set('contractAddress', contractAddress);
      url.searchParams.set('tokenId', tokenId);

      const res = await fetch(url.toString());
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setNft(data.nft || null);
    } catch (e) {
      setError(e.message || 'Failed to load NFT metadata');
    } finally {
      setLoading(false);
    }
  }, [contractAddress, tokenId]);

  useEffect(() => {
    if (contractAddress && tokenId) fetchMetadata();
  }, [contractAddress, tokenId, fetchMetadata]);

  /* ════════════════════════════════════════
     SKELETON STATE
     ════════════════════════════════════════ */
  if (loading) {
    return (
      <PageShell>
        <div className="max-w-[1400px] mx-auto px-6 md:px-8 py-8">
          {/* Back link skeleton */}
          <Skeleton variant="text" className="!w-20 mb-6" />

          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Left */}
            <div className="space-y-4">
              <Skeleton className="aspect-[3/4] w-full !rounded-card" />
              <Skeleton className="h-24 w-full !rounded-card" />
            </div>
            {/* Right */}
            <div className="space-y-5">
              <div className="flex gap-2">
                <Skeleton variant="text" className="!w-20" />
                <Skeleton variant="text" className="!w-16" />
              </div>
              <Skeleton variant="title" className="!h-10 !w-3/4" />
              <Skeleton variant="text" className="!w-1/2" />
              <Skeleton className="h-36 w-full !rounded-card" />
              <Skeleton className="h-32 w-full !rounded-card" />
              <Skeleton className="h-44 w-full !rounded-card" />
            </div>
          </div>
        </div>
      </PageShell>
    );
  }

  /* ════════════════════════════════════════
     ERROR STATE
     ════════════════════════════════════════ */
  if (error || !nft) {
    return (
      <PageShell>
        <div className="max-w-[1400px] mx-auto px-6 md:px-8 py-20 text-center animate-fade-in">
          <AlertCircle size={36} className="text-danger mx-auto mb-4" />
          <p className="text-danger text-sm mb-2">
            {error || 'NFT not found'}
          </p>
          <p className="text-muted-dim text-xs mb-6">
            Check the contract address and token ID, or try a different network.
          </p>
          <div className="flex gap-3 justify-center">
            <Button variant="secondary" size="md" onClick={fetchMetadata}>
              Retry
            </Button>
            <Link href="/explore">
              <Button variant="ghost" size="md">
                <ArrowLeft size={14} /> Explore
              </Button>
            </Link>
          </div>
        </div>
      </PageShell>
    );
  }

  /* ════════════════════════════════════════
     RESOLVED DATA
     ════════════════════════════════════════ */
  const image =
    ipfs(nft.image) ||
    ipfs(nft.raw?.metadata?.image) ||
    ipfs(nft.raw?.image?.cachedUrl);
  const name = nft.name || `#${tokenId}`;
  const description =
    nft.description ||
    nft.raw?.description ||
    nft.raw?.metadata?.description ||
    '';
  const collectionName =
    nft.collectionName || nft.raw?.contract?.name || 'Collection';

  // Traits — try multiple possible locations
  const traits =
    nft.raw?.metadata?.attributes ||
    nft.raw?.raw?.metadata?.attributes ||
    [];

  const chain = 'Ethereum';
  const ownerAddr = nft.raw?.owners?.[0] || '';

  return (
    <PageShell>
      <div className="max-w-[1400px] mx-auto px-6 md:px-8 py-8">
        {/* Back */}
        <Link
          href="/explore"
          className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-accent transition-colors mb-6"
        >
          <ArrowLeft size={14} /> Back
        </Link>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 animate-fade-in">
          {/* ── Left: Media ── */}
          <div className="space-y-4">
            <div className="rounded-card overflow-hidden glass-card">
              <NFTMedia src={image} alt={name} aspect="portrait" priority />
            </div>
            {description && (
              <Card className="p-5">
                <h3 className="text-sm font-semibold text-text mb-2">
                  Description
                </h3>
                <p className="text-sm text-muted leading-relaxed">
                  {description}
                </p>
              </Card>
            )}
          </div>

          {/* ── Right: Info ── */}
          <div className="space-y-5">
            {/* Header */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Badge color="accent">{chain}</Badge>
                <Badge color="default">#{tokenId}</Badge>
              </div>
              <h1 className="font-display text-3xl sm:text-4xl font-bold text-text">
                {name}
              </h1>
              <p className="text-sm text-muted">
                From <span className="text-accent">{collectionName}</span>
              </p>
            </div>

            {/* Action card */}
            <Card className="p-5 space-y-4">
              <p className="text-xs text-muted-dim">
                Listing data is not available from on-chain metadata.
              </p>
              <div className="flex gap-3">
                <Button variant="primary" size="lg" className="flex-1">
                  Buy Now
                </Button>
                <Button variant="secondary" size="lg">
                  <Heart size={16} />
                </Button>
                <Button variant="secondary" size="lg">
                  <Share2 size={16} />
                </Button>
              </div>
            </Card>

            {/* Token details */}
            <Card className="p-5 space-y-3">
              <h3 className="text-sm font-semibold text-text">
                Token Details
              </h3>
              <div className="space-y-2.5">
                {[
                  [
                    'Contract',
                    contractAddress
                      ? `${contractAddress.slice(0, 14)}…`
                      : '—',
                  ],
                  ['Token ID', tokenId || '—'],
                  ['Chain', chain],
                  [
                    'Owner',
                    ownerAddr ? `${ownerAddr.slice(0, 14)}…` : '—',
                  ],
                ].map(([label, value]) => (
                  <div key={label} className="flex justify-between text-sm">
                    <span className="text-muted">{label}</span>
                    <span className="text-text font-mono text-xs">
                      {value}
                    </span>
                  </div>
                ))}
              </div>
            </Card>

            {/* Traits — only loaded on this detail page */}
            {traits.length > 0 && (
              <Card className="p-5 space-y-3">
                <h3 className="text-sm font-semibold text-text">Traits</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {traits.map((trait, i) => (
                    <div
                      key={i}
                      className="bg-surface2/50 rounded-xl p-3 border border-border-light text-center"
                    >
                      <p className="text-[10px] text-accent font-mono uppercase tracking-wider">
                        {trait.trait_type || trait.traitType || 'Trait'}
                      </p>
                      <p className="text-sm text-text font-medium mt-1">
                        {trait.value ?? '—'}
                      </p>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* External link */}
            <a
              href={`https://etherscan.io/nft/${contractAddress}/${tokenId}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <Button variant="ghost" size="md" className="w-full">
                <ExternalLink size={14} /> View on Etherscan
              </Button>
            </a>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
