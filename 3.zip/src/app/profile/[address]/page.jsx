'use client';

import { useParams } from 'next/navigation';
import { Wallet, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import PageShell from '@/components/layout/PageShell';
import NFTGridAlchemy from '@/components/nft/NFTGridAlchemy';

export default function ProfilePage() {
  const params = useParams();
  const address = params?.address || '';

  return (
    <PageShell>
      <div className="max-w-[1400px] mx-auto px-6 md:px-8 py-8">
        <div className="mb-8">
          <Link
            href="/explore"
            className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-accent transition-colors mb-4"
          >
            <ArrowLeft size={14} /> Back to Explore
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full glass flex items-center justify-center">
              <Wallet size={20} className="text-accent" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold text-text">
                Wallet Portfolio
              </h1>
              <p className="text-xs text-muted-dim font-mono mt-0.5 truncate max-w-md">
                {address}
              </p>
            </div>
          </div>
        </div>

        <NFTGridAlchemy owner={address} />
      </div>
    </PageShell>
  );
}
