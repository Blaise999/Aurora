'use client';
import { useRef, useMemo } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import NFTCard from '@/components/nft/NFTCard';
import { featuredNFTs } from '@/lib/mock/nfts';
import { normalizeUiNfts } from '@/components/nft/normalizeUiNft';

export default function FeaturedNFTs() {
  const scrollRef = useRef(null);
  const nfts = useMemo(() => normalizeUiNfts(featuredNFTs), []);

  const scroll = (dir) => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({ left: dir * 320, behavior: 'smooth' });
  };

  return (
    <section className="py-20 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 md:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl font-bold text-text">Featured</h2>
            <p className="text-sm text-muted mt-1.5">Hand-picked pieces from top collections</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => scroll(-1)} className="w-10 h-10 rounded-xl glass flex items-center justify-center text-muted hover:text-text transition-colors">
              <ChevronLeft size={18} />
            </button>
            <button onClick={() => scroll(1)} className="w-10 h-10 rounded-xl glass flex items-center justify-center text-muted hover:text-text transition-colors">
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
      <div
        ref={scrollRef}
        className="flex gap-5 overflow-x-auto scrollbar-hide px-6 md:px-8 snap-x snap-mandatory pb-4"
        style={{ scrollbarWidth: 'none' }}
      >
        <div className="shrink-0 w-[calc((100%-1400px)/2+1.5rem)] hidden xl:block" />
        {nfts.map((nft, i) => (
          <div key={nft.id} className="shrink-0 w-[280px] snap-start">
            <NFTCard nft={nft} index={i} />
          </div>
        ))}
        <div className="shrink-0 w-8" />
      </div>
    </section>
  );
}
