'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Menu, X, Wallet } from 'lucide-react';
import Button from '@/components/ui/Button';

const navLinks = [
  { label: 'Explore', href: '/explore' },
  { label: 'Mint', href: '/mint' },
  { label: 'News', href: '/news' },
];

export default function Header({ fused = false }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const isCompact = !fused || scrolled;

  return (
    <>
      <header
        className={`
          fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-out
          ${isCompact
            ? 'glass-strong py-3 shadow-soft'
            : 'bg-transparent py-5'
          }
        `}
      >
        <div className="max-w-[1400px] mx-auto px-6 md:px-8 flex items-center justify-between">
          {/* Logo — .png placeholder ready */}
          <Link href="/" className="flex items-center gap-2.5 group">
            {/* Replace the div below with <img src="/pictures/aurora-logo.png" ... /> when ready */}
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-accent to-accent-violet flex items-center justify-center
              group-hover:shadow-glow transition-shadow duration-300 overflow-hidden">
              {/* <img src="/pictures/aurora-logo.png" alt="AuroraNft" className="w-full h-full object-contain" /> */}
              <span className="font-display font-bold text-bg text-sm">A</span>
            </div>
            <span className="font-display font-semibold text-lg tracking-tight text-text">
              Aurora<span className="gradient-text">Nft</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-2 text-sm text-muted hover:text-text transition-colors duration-200 rounded-lg hover:bg-white/[0.04]"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-3">
            <Button variant="secondary" size="sm" className="hidden md:flex">
              <Wallet size={16} />
              Connect
            </Button>
            <button
              className="md:hidden p-2 text-muted hover:text-text transition-colors"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-bg/80 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="absolute top-0 right-0 w-72 h-full glass-strong p-6 pt-20 flex flex-col gap-2">
            {navLinks.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-3 text-base text-muted hover:text-text rounded-xl hover:bg-white/[0.04] transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <div className="mt-4 pt-4 border-t border-border">
              <Button variant="primary" size="md" className="w-full">
                <Wallet size={16} /> Connect Wallet
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
