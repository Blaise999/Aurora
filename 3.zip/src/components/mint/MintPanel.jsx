'use client';
import { useState } from 'react';
import { Wallet, AlertTriangle, Check, Loader2, Settings } from 'lucide-react';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import QuantityStepper from './QuantityStepper';
import TxDrawer from './TxDrawer';

const states = ['disconnected', 'connected', 'wrong_network', 'sale_live', 'tx_pending', 'tx_success', 'tx_error'];

export default function MintPanel({ stats }) {
  const [currentState, setCurrentState] = useState('sale_live');
  const [quantity, setQuantity] = useState(1);
  const [showDrawer, setShowDrawer] = useState(false);
  const [showDevMenu, setShowDevMenu] = useState(false);

  const price = parseFloat(stats?.price) || 0.08;
  const total = (price * quantity).toFixed(4);
  const progress = stats ? (stats.minted / stats.totalSupply) * 100 : 42.37;

  return (
    <>
      <div className="glass-card rounded-card p-6 sm:p-8 space-y-6 relative">
        {/* Dev state switch */}
        <button
          onClick={() => setShowDevMenu(!showDevMenu)}
          className="absolute top-4 right-4 p-1.5 text-muted-dim hover:text-muted transition-colors rounded-lg hover:bg-white/[0.04]"
          title="Dev: Switch States"
        >
          <Settings size={14} />
        </button>
        {showDevMenu && (
          <div className="absolute top-12 right-4 glass-strong rounded-xl p-2 z-10 min-w-[160px]">
            {states.map(s => (
              <button
                key={s}
                onClick={() => { setCurrentState(s); setShowDevMenu(false); }}
                className={`w-full text-left px-3 py-1.5 text-xs rounded-lg transition-colors
                  ${currentState === s ? 'bg-accent/10 text-accent' : 'text-muted hover:text-text hover:bg-white/[0.04]'}`}
              >
                {s.replace('_', ' ')}
              </button>
            ))}
          </div>
        )}

        {/* Header */}
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h2 className="font-display text-xl font-semibold text-text">Mint</h2>
            {currentState === 'sale_live' && <Badge color="success" dot>Live</Badge>}
            {currentState === 'tx_pending' && <Badge color="warning" dot>Pending</Badge>}
            {currentState === 'tx_success' && <Badge color="success" dot>Complete</Badge>}
            {currentState === 'tx_error' && <Badge color="danger" dot>Error</Badge>}
          </div>
          <p className="text-sm text-muted">Ethereal Voids Collection</p>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted">Minted</span>
            <span className="text-text font-mono">{stats?.minted?.toLocaleString() || '4,237'} / {stats?.totalSupply?.toLocaleString() || '10,000'}</span>
          </div>
          <div className="h-2 bg-surface2 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-accent to-accent-violet transition-all duration-700"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Price info */}
        <div className="bg-surface2/40 rounded-xl p-4 space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted">Price</span>
            <span className="text-text font-mono font-medium">{stats?.price || '0.08 ETH'}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted">Max per wallet</span>
            <span className="text-text font-mono">{stats?.maxPerWallet || 5}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted">Network</span>
            <span className="text-text font-mono">{stats?.chain || 'Ethereum'}</span>
          </div>
        </div>

        {/* Disconnected State */}
        {currentState === 'disconnected' && (
          <div className="space-y-4">
            <div className="text-center py-4 space-y-2">
              <Wallet size={32} className="mx-auto text-muted-dim" />
              <p className="text-sm text-muted">Connect your wallet to mint</p>
            </div>
            <Button variant="primary" size="lg" className="w-full">
              <Wallet size={16} /> Connect Wallet
            </Button>
          </div>
        )}

        {/* Wrong Network */}
        {currentState === 'wrong_network' && (
          <div className="space-y-4">
            <div className="bg-warning/10 border border-warning/20 rounded-xl p-4 flex items-start gap-3">
              <AlertTriangle size={18} className="text-warning mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium text-warning">Wrong Network</p>
                <p className="text-xs text-muted mt-1">Please switch to Ethereum Mainnet to continue.</p>
              </div>
            </div>
            <Button variant="primary" size="lg" className="w-full">Switch Network</Button>
          </div>
        )}

        {/* Connected / Sale Live */}
        {(currentState === 'connected' || currentState === 'sale_live') && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted">Quantity</span>
              <QuantityStepper value={quantity} onChange={setQuantity} max={5} />
            </div>
            <div className="flex justify-between items-center pt-3 border-t border-border-light">
              <span className="text-sm font-medium text-text">Total</span>
              <span className="text-xl font-mono font-semibold text-accent">{total} ETH</span>
            </div>
            <Button variant="primary" size="lg" className="w-full" onClick={() => setShowDrawer(true)}>
              Mint Now
            </Button>
          </div>
        )}

        {/* Pending */}
        {currentState === 'tx_pending' && (
          <div className="text-center py-6 space-y-3">
            <Loader2 size={36} className="mx-auto text-accent animate-spin" />
            <p className="text-sm text-muted">Transaction pending...</p>
          </div>
        )}

        {/* Success */}
        {currentState === 'tx_success' && (
          <div className="text-center py-6 space-y-4">
            <div className="w-14 h-14 rounded-full bg-success/10 flex items-center justify-center mx-auto">
              <Check size={28} className="text-success" />
            </div>
            <p className="text-text font-semibold">Successfully minted!</p>
            <Button variant="secondary" size="md" className="mx-auto">View NFT</Button>
          </div>
        )}

        {/* Error */}
        {currentState === 'tx_error' && (
          <div className="space-y-4">
            <div className="bg-danger/10 border border-danger/20 rounded-xl p-4 flex items-start gap-3">
              <AlertTriangle size={18} className="text-danger mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium text-danger">Transaction Failed</p>
                <p className="text-xs text-muted mt-1">User rejected the transaction or insufficient funds.</p>
              </div>
            </div>
            <Button variant="primary" size="lg" className="w-full">Try Again</Button>
          </div>
        )}
      </div>

      <TxDrawer
        open={showDrawer}
        onClose={() => setShowDrawer(false)}
        quantity={quantity}
        price={String(price)}
      />
    </>
  );
}
