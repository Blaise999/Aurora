'use client';
import { memo } from 'react';
import Link from 'next/link';
import { Heart } from 'lucide-react';
import NFTMedia from './NFTMedia';
import Badge from '@/components/ui/Badge';

const NFTCard = memo(function NFTCard({ nft, index = 0 }) {
  const hasPrice = nft.price && nft.price !== '—';
  const hasLastSale = nft.lastSale && nft.lastSale !== '—';

  // Link to /nft/[contractAddress]/[tokenId] for live data,
  // fallback to /nft/[id] for mock data without contractAddress
  const detailHref =
    nft.contractAddress && nft.tokenId
      ? `/nft/${nft.contractAddress}/${nft.tokenId}`
      : `/nft/${nft.id}`;

  return (
    <Link href={detailHref} prefetch={false}>
      <div
        className="group rounded-card overflow-hidden glass-card card-hover animate-fade-in"
        style={{ animationDelay: `${Math.min(index, 11) * 60}ms` }}
      >
        <div className="relative">
          <NFTMedia
            src={nft.normalized_metadata?.image}
            alt={nft.name}
            hasVideo={nft.hasMedia && index % 7 === 0}
          />
          {/* Hover overlay */}
          <div
            className="absolute inset-0 bg-gradient-to-t from-surface/80 via-transparent to-transparent
            opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4"
          >
            <span className="text-xs text-accent font-mono">View Details →</span>
          </div>
          {/* Chain badge */}
          <div className="absolute top-3 left-3">
            <Badge
              color="default"
              className="!bg-black/40 backdrop-blur-sm !border-white/10 !text-[10px]"
            >
              {nft.chain}
            </Badge>
          </div>
          {/* Favorite */}
          <button
            className="absolute top-3 right-3 w-8 h-8 rounded-full glass flex items-center justify-center
              opacity-0 group-hover:opacity-100 transition-opacity duration-200 hover:bg-white/10"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
          >
            <Heart size={14} className="text-muted" />
          </button>
        </div>

        <div className="p-4 space-y-2">
          <p className="text-[11px] text-muted-dim font-mono truncate">
            {nft.collectionName}
          </p>
          <p className="text-sm font-display font-semibold text-text truncate group-hover:text-accent transition-colors duration-200">
            {nft.name}
          </p>

          {hasPrice || hasLastSale ? (
            <div className="flex items-center justify-between pt-1.5 border-t border-border-light">
              <div>
                <p className="text-[10px] text-muted-dim">Price</p>
                <p className="text-sm text-accent font-mono font-medium">
                  {nft.price}
                </p>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-muted-dim">Last sale</p>
                <p className="text-sm text-muted font-mono">{nft.lastSale}</p>
              </div>
            </div>
          ) : (
            <div className="pt-1.5 border-t border-border-light">
              <p className="text-[10px] text-muted-dim/60 italic">
                No listing data
              </p>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
});

export default NFTCard;
