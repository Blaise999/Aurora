'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import NFTGrid from './NFTGrid';
import { normalizeUiNfts } from './normalizeUiNft';
import Button from '@/components/ui/Button';

/**
 * NFTGridCollection — collection NFTs via /api/nft/collection
 * Supports startToken / nextToken pagination.
 */
export default function NFTGridCollection({ contractAddress }) {
  const [nfts, setNfts] = useState([]);
  const [nextToken, setNextToken] = useState(null);
  const [loading, setLoading] = useState(false);
  const [initialLoad, setInitialLoad] = useState(true);
  const [error, setError] = useState(null);

  const prevAddress = useRef(contractAddress);
  const fetchingRef = useRef(false);

  const fetchPage = useCallback(async (address, startToken, append) => {
    if (fetchingRef.current) return;
    fetchingRef.current = true;
    setLoading(true);
    setError(null);

    try {
      const url = new URL('/api/nft/collection', window.location.origin);
      url.searchParams.set('contractAddress', address);
      if (startToken) url.searchParams.set('startToken', startToken);

      const res = await fetch(url.toString());
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const data = await res.json();
      if (data.error) throw new Error(data.error);

      const rawList = data.nfts || [];
      const normalized = normalizeUiNfts(rawList);

      setNfts((prev) => {
        const combined = append ? [...prev, ...normalized] : normalized;
        const seen = new Set();
        return combined.filter((n) => {
          if (seen.has(n.id)) return false;
          seen.add(n.id);
          return true;
        });
      });

      setNextToken(data.nextToken || null);

      if (!append) preloadImages(normalized.slice(0, 4));
    } catch (e) {
      setError(e.message || 'Failed to load collection');
    } finally {
      setLoading(false);
      setInitialLoad(false);
      fetchingRef.current = false;
    }
  }, []);

  useEffect(() => {
    if (!contractAddress) return;

    if (prevAddress.current !== contractAddress) {
      setNfts([]);
      setNextToken(null);
      setInitialLoad(true);
      prevAddress.current = contractAddress;
    }

    fetchPage(contractAddress, null, false);
  }, [contractAddress, fetchPage]);

  const handleLoadMore = useCallback(() => {
    if (!nextToken || loading) return;
    fetchPage(contractAddress, nextToken, true);
  }, [contractAddress, nextToken, loading, fetchPage]);

  return (
    <div>
      <NFTGrid nfts={nfts} loading={initialLoad} columns={4} />

      {error && !initialLoad && (
        <div className="mt-4 px-4 py-3 rounded-xl bg-danger/10 border border-danger/20 text-sm text-danger text-center animate-fade-in">
          {error} — previous data is still shown.
        </div>
      )}

      {!initialLoad && !loading && nfts.length === 0 && !error && (
        <div className="text-center py-20 animate-fade-in">
          <p className="text-muted text-sm">No NFTs found in this collection.</p>
          <p className="text-muted-dim text-xs mt-2">
            Verify the contract address and network.
          </p>
        </div>
      )}

      {nextToken && !initialLoad && (
        <div className="flex justify-center mt-10">
          <Button
            variant="secondary"
            size="lg"
            onClick={handleLoadMore}
            disabled={loading}
          >
            {loading ? 'Loading…' : 'Load More'}
          </Button>
        </div>
      )}
    </div>
  );
}

function preloadImages(nfts) {
  if (typeof document === 'undefined') return;
  nfts.forEach((nft) => {
    const src = nft.normalized_metadata?.image;
    if (!src || src.startsWith('linear-gradient')) return;
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'image';
    link.href = src;
    document.head.appendChild(link);
  });
}
