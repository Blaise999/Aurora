/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  images: {
    // serve modern formats where possible
    formats: ["image/avif", "image/webp"],

    // ✅ important: allow Next to generate big srcset widths (prevents blurry hero on DPR screens)
    deviceSizes: [320, 420, 640, 750, 828, 1080, 1200, 1600, 1920, 2560, 3200, 3840],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],

    // ✅ allow remote NFT images (Alchemy/IPFS gateways) if you use them
    remotePatterns: [
      { protocol: "https", hostname: "nft-cdn.alchemy.com" },
      { protocol: "https", hostname: "ipfs.io" },
      { protocol: "https", hostname: "gateway.pinata.cloud" },
      { protocol: "https", hostname: "cloudflare-ipfs.com" },
      { protocol: "https", hostname: "nftstorage.link" },
    ],
  },
};

module.exports = nextConfig;