-- AuroraNft — Supabase Schema
-- Run in Supabase SQL Editor

CREATE TABLE IF NOT EXISTS nft_metadata_cache (
  id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  chain_id         int NOT NULL,
  contract_address text NOT NULL,
  token_id         text NOT NULL,
  name             text,
  description      text,
  image_url        text,
  attributes       jsonb DEFAULT '[]'::jsonb,
  updated_at       timestamptz DEFAULT now(),
  UNIQUE (chain_id, contract_address, token_id)
);

CREATE TABLE IF NOT EXISTS user_nfts (
  id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  chain_id         int NOT NULL,
  contract_address text NOT NULL,
  token_id         text NOT NULL,
  owner_address    text NOT NULL,
  minter_address   text,
  tx_hash          text NOT NULL,
  minted_at        timestamptz DEFAULT now(),
  status           text NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending','confirmed','failed')),
  UNIQUE (chain_id, contract_address, token_id),
  UNIQUE (tx_hash)
);

CREATE INDEX IF NOT EXISTS idx_user_nfts_owner ON user_nfts (owner_address);
CREATE INDEX IF NOT EXISTS idx_user_nfts_status ON user_nfts (status);
CREATE INDEX IF NOT EXISTS idx_metadata_lookup ON nft_metadata_cache (chain_id, contract_address, token_id);

ALTER TABLE nft_metadata_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_nfts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "metadata_read_all" ON nft_metadata_cache FOR SELECT USING (true);
CREATE POLICY "metadata_no_anon_write" ON nft_metadata_cache FOR INSERT WITH CHECK (false);
CREATE POLICY "user_nfts_read_all" ON user_nfts FOR SELECT USING (true);
CREATE POLICY "user_nfts_no_anon_write" ON user_nfts FOR INSERT WITH CHECK (false);
