import { NextResponse } from "next/server";
import { createPublicClient, http, decodeEventLog } from "viem";
import { base, baseSepolia } from "viem/chains";
import { getSession } from "@/lib/auth/session";
import { getSupabase } from "@/lib/db/supabase";
import { AURORA_NFT_ABI } from "@/lib/web3/contract";

export const runtime = "nodejs";

function getChain() {
  const id = parseInt(process.env.NEXT_PUBLIC_CHAIN_ID || "84532", 10);
  return id === 8453 ? base : baseSepolia;
}

/**
 * POST /api/mint/confirm
 * Body: { txHash }
 *
 * 1. Require session cookie → wallet address
 * 2. Fetch tx receipt from Base RPC (server-side, not trusting client)
 * 3. Validate receipt: status, to == our contract, Transfer logs
 * 4. Extract tokenId(s)
 * 5. Upsert nft_metadata_cache + user_nfts
 */
export async function POST(req: Request) {
  try {
    // 1. Auth
    const wallet = await getSession();
    if (!wallet) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { txHash } = await req.json();
    if (!txHash || typeof txHash !== "string") {
      return NextResponse.json({ error: "Missing txHash" }, { status: 400 });
    }

    const contractAddress = (process.env.NEXT_PUBLIC_AURORA_CONTRACT || "").toLowerCase();
    if (!contractAddress) {
      return NextResponse.json({ error: "Contract not configured" }, { status: 500 });
    }

    const chain = getChain();
    const rpcUrl = process.env.BASE_RPC_URL || chain.rpcUrls.default.http[0];

    // 2. Fetch receipt
    const client = createPublicClient({
      chain,
      transport: http(rpcUrl),
    });

    const receipt = await client.getTransactionReceipt({
      hash: txHash as `0x${string}`,
    });

    // 3. Validate
    if (receipt.status !== "success") {
      return NextResponse.json({ error: "Transaction failed on-chain" }, { status: 400 });
    }

    if (receipt.to?.toLowerCase() !== contractAddress) {
      return NextResponse.json({ error: "Transaction not to our contract" }, { status: 400 });
    }

    // 4. Parse Transfer events
    const transferLogs: Array<{ tokenId: string; to: string }> = [];

    for (const log of receipt.logs) {
      if (log.address.toLowerCase() !== contractAddress) continue;
      try {
        const decoded = decodeEventLog({
          abi: AURORA_NFT_ABI,
          data: log.data,
          topics: log.topics,
        });
        if (decoded.eventName === "Transfer") {
          const args = decoded.args as any;
          transferLogs.push({
            tokenId: args.tokenId.toString(),
            to: (args.to as string).toLowerCase(),
          });
        }
      } catch {
        // not a Transfer log, skip
      }
    }

    if (transferLogs.length === 0) {
      return NextResponse.json({ error: "No Transfer events found" }, { status: 400 });
    }

    // Verify at least one Transfer went to the session wallet
    const userTransfers = transferLogs.filter((t) => t.to === wallet.toLowerCase());
    if (userTransfers.length === 0) {
      return NextResponse.json({ error: "Transfer not to your wallet" }, { status: 403 });
    }

    // 5. Write to DB
    const supabase = getSupabase();
    const chainId = chain.id;

    for (const transfer of userTransfers) {
      // Upsert metadata cache
      await supabase.from("nft_metadata_cache").upsert(
        {
          chain_id: chainId,
          contract_address: contractAddress,
          token_id: transfer.tokenId,
          name: `AuroraNft #${transfer.tokenId}`,
          description: "AuroraNft collection piece",
          image_url: null, // Will be populated by metadata resolver later
          updated_at: new Date().toISOString(),
        },
        { onConflict: "chain_id,contract_address,token_id" }
      );

      // Upsert user_nfts
      await supabase.from("user_nfts").upsert(
        {
          chain_id: chainId,
          contract_address: contractAddress,
          token_id: transfer.tokenId,
          owner_address: wallet.toLowerCase(),
          minter_address: wallet.toLowerCase(),
          tx_hash: txHash.toLowerCase(),
          minted_at: new Date().toISOString(),
          status: "confirmed",
        },
        { onConflict: "chain_id,contract_address,token_id" }
      );
    }

    return NextResponse.json({
      ok: true,
      contractAddress,
      tokenIds: userTransfers.map((t) => t.tokenId),
      count: userTransfers.length,
    });
  } catch (e: any) {
    console.error("Mint confirm error:", e);
    return NextResponse.json({ error: e?.message || "Failed" }, { status: 500 });
  }
}
