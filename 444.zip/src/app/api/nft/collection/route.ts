import { NextResponse } from "next/server";
import { alchemyGet } from "@/lib/alchemy/nft";

export const runtime = "nodejs";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const contractAddress = searchParams.get("contractAddress") || "";
    const startToken = searchParams.get("startToken") || undefined;

    if (!contractAddress) {
      return NextResponse.json({ error: "Missing contractAddress" }, { status: 400 });
    }

    // getNFTsForCollection supports pagination via startToken + withMetadata :contentReference[oaicite:7]{index=7}
    const payload = await alchemyGet("getNFTsForCollection", {
      contractAddress,
      withMetadata: "true",
      startToken,
    });

    return NextResponse.json(payload);
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Failed" }, { status: 500 });
  }
}