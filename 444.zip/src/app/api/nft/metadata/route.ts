import { NextResponse } from "next/server";
import { alchemyGet, normalizeSingleNft } from "@/lib/alchemy/nft";

export const runtime = "nodejs";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const contractAddress = searchParams.get("contractAddress") || "";
    const tokenId = searchParams.get("tokenId") || "";
    const refreshCache = searchParams.get("refreshCache") || undefined;

    if (!contractAddress || !tokenId) {
      return NextResponse.json({ error: "Missing contractAddress or tokenId" }, { status: 400 });
    }

    // getNFTMetadata (Alchemy NFT API v3) :contentReference[oaicite:6]{index=6}
    const payload = await alchemyGet("getNFTMetadata", {
      contractAddress,
      tokenId,
      refreshCache, // set "true" if you want to force refresh
    });

    return NextResponse.json({ nft: normalizeSingleNft(payload) });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Failed" }, { status: 500 });
  }
}