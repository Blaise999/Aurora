import { NextResponse } from "next/server";
import { alchemyOwnedToUi } from "@/lib/alchemy/nft-normalize";

export const runtime = "nodejs";

function requireEnv(name: string) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

async function alchemyGet(path: string, params: Record<string, string | undefined>) {
  const apiKey = requireEnv("ALCHEMY_API_KEY");
  const network = process.env.ALCHEMY_NETWORK || "eth-mainnet";

  const url = new URL(`https://${network}.g.alchemy.com/nft/v3/${apiKey}/${path}`);
  Object.entries(params).forEach(([k, v]) => {
    if (v) url.searchParams.set(k, v);
  });

  const res = await fetch(url.toString(), {
    headers: { accept: "application/json" },
    next: { revalidate: 30 },
  });

  if (!res.ok) throw new Error(`Alchemy ${res.status}`);
  return res.json();
}

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const owner = searchParams.get("owner") || "";
    const pageKey = searchParams.get("pageKey") || undefined;

    if (!owner) return NextResponse.json({ error: "Missing owner" }, { status: 400 });

    // Alchemy v3: getNFTsForOwner :contentReference[oaicite:1]{index=1}
    const payload = await alchemyGet("getNFTsForOwner", {
      owner,
      pageKey,
      pageSize: "50",
    });

    return NextResponse.json({
      nfts: alchemyOwnedToUi(payload, "Ethereum"),
      pageKey: payload?.pageKey ?? null,
      totalCount: payload?.totalCount ?? null,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Failed" }, { status: 500 });
  }
}