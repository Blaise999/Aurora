'use client';
import { useParams, useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { ExternalLink, Heart, Share2, ArrowLeft, RefreshCw } from 'lucide-react';
import PageShell from '@/components/layout/PageShell';
import NFTMedia from '@/components/nft/NFTMedia';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import Skeleton from '@/components/ui/Skeleton';
import { getExplorerUrl } from '@/lib/web3/contract';

export default function NFTDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { contractAddress, tokenId } = params || {};
  const [nft, setNft] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!contractAddress || !tokenId) return;
    let alive = true;
    (async () => {
      setLoading(true); setError(null);
      try {
        const res = await fetch(`/api/nft/metadata?contractAddress=${encodeURIComponent(contractAddress)}&tokenId=${encodeURIComponent(tokenId)}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        if (alive) setNft(data.nft);
      } catch (e) { if (alive) setError(e.message); }
      finally { if (alive) setLoading(false); }
    })();
    return () => { alive = false; };
  }, [contractAddress, tokenId]);

  const explorerUrl = getExplorerUrl();
  const traits = nft?.raw?.metadata?.attributes || nft?.raw?.raw?.metadata?.attributes || [];

  return (
    <PageShell>
      <div className="max-w-[1400px] mx-auto px-6 md:px-8 py-8">
        {/* Back button */}
        <button onClick={() => router.back()} className="flex items-center gap-2 text-sm text-muted hover:text-text mb-6 transition-colors">
          <ArrowLeft size={16} /> Back
        </button>

        {/* Loading skeleton */}
        {loading && (
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
            <Skeleton className="aspect-[3/4] w-full" />
            <div className="space-y-5">
              <Skeleton variant="title" className="w-1/3" />
              <Skeleton variant="title" className="w-2/3" />
              <Skeleton className="h-40 w-full" />
              <Skeleton className="h-32 w-full" />
            </div>
          </div>
        )}

        {/* Error */}
        {error && !loading && (
          <div className="text-center py-20 space-y-4">
            <p className="text-danger text-sm">{error}</p>
            <Button variant="secondary" size="md" onClick={() => window.location.reload()}>
              <RefreshCw size={14} /> Retry
            </Button>
          </div>
        )}

        {/* NFT detail */}
        {nft && !loading && (
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Left: Media */}
            <div className="space-y-4">
              <div className="rounded-card overflow-hidden glass-card">
                <NFTMedia src={nft.image} alt={nft.name} aspect="portrait" priority />
              </div>
              {nft.description && (
                <Card className="p-5">
                  <h3 className="text-sm font-semibold text-text mb-2">Description</h3>
                  <p className="text-sm text-muted leading-relaxed">{nft.description}</p>
                </Card>
              )}
            </div>

            {/* Right: Info */}
            <div className="space-y-5">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge color="accent">Base</Badge>
                  {tokenId && <Badge color="default">#{tokenId}</Badge>}
                </div>
                <h1 className="font-display text-3xl sm:text-4xl font-bold text-text">{nft.name || `#${tokenId}`}</h1>
                {nft.collectionName && (
                  <p className="text-sm text-muted">From <span className="text-accent">{nft.collectionName}</span></p>
                )}
              </div>

              <div className="flex gap-3">
                <Button variant="secondary" size="lg"><Heart size={16} /></Button>
                <Button variant="secondary" size="lg"><Share2 size={16} /></Button>
              </div>

              <Card className="p-5 space-y-3">
                <h3 className="text-sm font-semibold text-text">Token Details</h3>
                <div className="space-y-2.5">
                  {[
                    ['Contract', contractAddress ? `${contractAddress.slice(0, 10)}…${contractAddress.slice(-6)}` : '—'],
                    ['Token ID', tokenId || '—'],
                    ['Chain', 'Base'],
                  ].map(([label, value]) => (
                    <div key={label} className="flex justify-between text-sm">
                      <span className="text-muted">{label}</span>
                      <span className="text-text font-mono text-xs">{value}</span>
                    </div>
                  ))}
                </div>
              </Card>

              {traits.length > 0 && (
                <Card className="p-5 space-y-3">
                  <h3 className="text-sm font-semibold text-text">Traits</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {traits.map((trait, i) => (
                      <div key={i} className="bg-surface2/50 rounded-xl p-3 border border-border-light text-center">
                        <p className="text-[10px] text-accent font-mono uppercase tracking-wider">{trait.trait_type}</p>
                        <p className="text-sm text-text font-medium mt-1">{trait.value}</p>
                      </div>
                    ))}
                  </div>
                </Card>
              )}

              <a href={`${explorerUrl}/token/${contractAddress}?a=${tokenId}`} target="_blank" rel="noopener noreferrer">
                <Button variant="ghost" size="md" className="w-full">
                  <ExternalLink size={14} /> View on Basescan
                </Button>
              </a>
            </div>
          </div>
        )}
      </div>
    </PageShell>
  );
}
