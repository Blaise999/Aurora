'use client';
import { useParams, useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { ExternalLink, Heart, Share2, Eye, Clock } from 'lucide-react';
import PageShell from '@/components/layout/PageShell';
import NFTMedia from '@/components/nft/NFTMedia';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import { getNFTById, provenanceHistory } from '@/lib/mock/nfts';

export default function NFTDetailPage() {
  const params = useParams();
  const router = useRouter();
  const rawId = params?.id;

  // Redirect contractAddress_tokenId to the proper route
  useEffect(() => {
    if (rawId && rawId.includes('_') && rawId.startsWith('0x')) {
      const parts = rawId.split('_');
      if (parts.length >= 2) {
        const contractAddr = parts[0];
        const tokenId = parts.slice(1).join('_');
        router.replace(`/nft/${contractAddr}/${tokenId}`);
      }
    }
  }, [rawId, router]);

  // If it's a redirect format, show nothing while redirecting
  if (rawId && rawId.includes('_') && rawId.startsWith('0x')) {
    return <PageShell><div className="py-40 text-center text-muted text-sm">Redirecting…</div></PageShell>;
  }

  const nft = getNFTById(rawId);
  const traits = nft.normalized_metadata?.attributes || [];

  return (
    <PageShell>
      <div className="max-w-[1400px] mx-auto px-6 md:px-8 py-8">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          <div className="space-y-4">
            <div className="rounded-card overflow-hidden glass-card">
              <NFTMedia src={nft.normalized_metadata?.image} alt={nft.name} aspect="portrait" />
            </div>
            <Card className="p-5">
              <h3 className="text-sm font-semibold text-text mb-2">Description</h3>
              <p className="text-sm text-muted leading-relaxed">{nft.normalized_metadata?.description}</p>
            </Card>
          </div>
          <div className="space-y-5">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Badge color="accent">{nft.chain}</Badge>
                <Badge color="default">#{nft.token_id}</Badge>
              </div>
              <h1 className="font-display text-3xl sm:text-4xl font-bold text-text">{nft.name}</h1>
              <p className="text-sm text-muted">From <span className="text-accent">{nft.collectionName}</span></p>
            </div>
            <div className="flex items-center gap-4 text-sm text-muted">
              <span className="flex items-center gap-1.5"><Eye size={14} /> {nft.views?.toLocaleString()} views</span>
              <span className="flex items-center gap-1.5"><Heart size={14} /> {nft.favorites} favorites</span>
            </div>
            <Card className="p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-dim">Current Price</p>
                  <p className="text-2xl font-display font-bold text-accent mt-1">{nft.price}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-dim">Last Sale</p>
                  <p className="text-lg font-mono text-muted mt-1">{nft.lastSale}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Button variant="primary" size="lg" className="flex-1">Buy Now</Button>
                <Button variant="secondary" size="lg"><Heart size={16} /></Button>
                <Button variant="secondary" size="lg"><Share2 size={16} /></Button>
              </div>
            </Card>
            <Card className="p-5 space-y-3">
              <h3 className="text-sm font-semibold text-text">Token Details</h3>
              <div className="space-y-2.5">
                {[['Contract', nft.token_address?.slice(0, 12) + '...'], ['Token ID', nft.token_id], ['Chain', nft.chain], ['Owner', nft.owner], ['Creator', nft.creator]].map(([label, value]) => (
                  <div key={label} className="flex justify-between text-sm">
                    <span className="text-muted">{label}</span>
                    <span className="text-text font-mono text-xs">{value}</span>
                  </div>
                ))}
              </div>
            </Card>
            {traits.length > 0 && (
              <Card className="p-5 space-y-3">
                <h3 className="text-sm font-semibold text-text">Traits</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {traits.map((trait, i) => (
                    <div key={i} className="bg-surface2/50 rounded-xl p-3 border border-border-light text-center">
                      <p className="text-[10px] text-accent font-mono uppercase tracking-wider">{trait.trait_type}</p>
                      <p className="text-sm text-text font-medium mt-1">{trait.value}</p>
                    </div>
                  ))}
                </div>
              </Card>
            )}
            <Card className="p-5 space-y-3">
              <h3 className="text-sm font-semibold text-text">Provenance</h3>
              <div className="space-y-0">
                {provenanceHistory.map((event, i) => (
                  <div key={i} className="flex items-start gap-3 py-2.5 border-b border-border-light last:border-0">
                    <div className="flex flex-col items-center">
                      <div className="w-2 h-2 rounded-full bg-accent mt-1.5" />
                      {i < provenanceHistory.length - 1 && <div className="w-px h-full bg-border-light mt-1" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm text-text font-medium">{event.event}</span>
                        <span className="text-[11px] text-muted-dim flex items-center gap-1"><Clock size={10} /> {event.date}</span>
                      </div>
                      <p className="text-xs text-muted font-mono mt-0.5">{event.from} → {event.to}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
            <Button variant="ghost" size="md" className="w-full">
              <ExternalLink size={14} /> View on Explorer
            </Button>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
