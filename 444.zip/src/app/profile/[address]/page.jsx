'use client';
import { useParams } from 'next/navigation';
import { useState, useEffect } from 'react';
import { ArrowLeft, Copy, Check, ExternalLink, Loader2 } from 'lucide-react';
import Link from 'next/link';
import PageShell from '@/components/layout/PageShell';
import NFTGrid from '@/components/nft/NFTGrid';
import NFTGridAlchemy from '@/components/nft/NFTGridAlchemy';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Skeleton from '@/components/ui/Skeleton';
import { NFTCardSkeleton } from '@/components/ui/Skeleton';
import { useAuth } from '@/hooks/useAuth';
import { getExplorerUrl } from '@/lib/web3/contract';

export default function ProfilePage() {
  const params = useParams();
  const walletAddress = params?.address;
  const { session, isAuthed } = useAuth();
  const [copied, setCopied] = useState(false);
  const [tab, setTab] = useState('minted'); // 'minted' | 'all'
  const [dbNfts, setDbNfts] = useState([]);
  const [dbLoading, setDbLoading] = useState(false);

  const isOwnProfile = isAuthed && session?.toLowerCase() === walletAddress?.toLowerCase();
  const shortAddr = walletAddress ? `${walletAddress.slice(0, 8)}…${walletAddress.slice(-6)}` : '';
  const explorerUrl = getExplorerUrl();

  const handleCopy = () => {
    if (walletAddress) navigator.clipboard.writeText(walletAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Fetch minted NFTs from DB
  useEffect(() => {
    if (tab !== 'minted' || !isOwnProfile) return;
    let alive = true;
    (async () => {
      setDbLoading(true);
      try {
        const res = await fetch('/api/profile/nfts');
        const data = await res.json();
        if (alive && data.nfts) setDbNfts(data.nfts);
      } catch { /* ignore */ }
      finally { if (alive) setDbLoading(false); }
    })();
    return () => { alive = false; };
  }, [tab, isOwnProfile]);

  return (
    <PageShell>
      <div className="max-w-[1400px] mx-auto px-6 md:px-8 py-8">
        {/* Header */}
        <Link href="/" className="flex items-center gap-2 text-sm text-muted hover:text-text mb-6 transition-colors">
          <ArrowLeft size={16} /> Home
        </Link>

        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-accent to-accent-violet flex items-center justify-center shrink-0">
            <span className="font-display font-bold text-bg text-xl">{walletAddress?.[2]?.toUpperCase() || '?'}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3">
              <h1 className="font-display text-2xl font-bold text-text truncate">{shortAddr}</h1>
              <button onClick={handleCopy} className="p-1.5 text-muted hover:text-text transition-colors" title="Copy address">
                {copied ? <Check size={14} className="text-success" /> : <Copy size={14} />}
              </button>
            </div>
            <div className="flex items-center gap-2 mt-1">
              {isOwnProfile && <Badge color="accent">Your Wallet</Badge>}
              <a href={`${explorerUrl}/address/${walletAddress}`} target="_blank" rel="noopener noreferrer"
                className="text-xs text-muted hover:text-accent font-mono flex items-center gap-1">
                <ExternalLink size={10} /> Basescan
              </a>
            </div>
          </div>
        </div>

        {/* Tabs */}
        {isOwnProfile && (
          <div className="flex gap-1 mb-6">
            <button
              onClick={() => setTab('minted')}
              className={`px-4 py-2 text-sm rounded-xl transition-colors ${tab === 'minted' ? 'bg-accent/10 text-accent font-medium' : 'text-muted hover:text-text hover:bg-white/[0.04]'}`}
            >
              My Mints (DB)
            </button>
            <button
              onClick={() => setTab('all')}
              className={`px-4 py-2 text-sm rounded-xl transition-colors ${tab === 'all' ? 'bg-accent/10 text-accent font-medium' : 'text-muted hover:text-text hover:bg-white/[0.04]'}`}
            >
              All NFTs (Chain)
            </button>
          </div>
        )}

        {/* Content */}
        {tab === 'minted' && isOwnProfile ? (
          <div>
            {dbLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                {Array.from({ length: 4 }).map((_, i) => <NFTCardSkeleton key={i} />)}
              </div>
            ) : dbNfts.length > 0 ? (
              <NFTGrid nfts={dbNfts} columns={4} />
            ) : (
              <div className="text-center py-20">
                <p className="text-muted text-sm">No minted NFTs yet.</p>
                <Link href="/mint">
                  <Button variant="primary" size="md" className="mt-4">Go Mint</Button>
                </Link>
              </div>
            )}
          </div>
        ) : (
          <NFTGridAlchemy owner={walletAddress} />
        )}
      </div>
    </PageShell>
  );
}
