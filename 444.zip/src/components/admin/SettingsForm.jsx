'use client';
import { useState } from 'react';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import { Save, AlertTriangle } from 'lucide-react';

export default function SettingsForm() {
  const [price, setPrice] = useState('0.08');
  const [mintWindow, setMintWindow] = useState('72');
  const [paused, setPaused] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  return (
    <div className="space-y-6">
      <div className="glass-card rounded-card p-6 space-y-5">
        <h3 className="font-display font-semibold text-text">Mint Configuration</h3>

        <Input
          label="Price (ETH)"
          value={price}
          onChange={e => setPrice(e.target.value)}
          placeholder="0.08"
          type="number"
          step="0.001"
        />

        <Input
          label="Mint Window (hours)"
          value={mintWindow}
          onChange={e => setMintWindow(e.target.value)}
          placeholder="72"
          type="number"
        />

        {/* Pause toggle */}
        <div className="flex items-center justify-between py-3 border-t border-border-light">
          <div>
            <p className="text-sm text-text font-medium">Sale Status</p>
            <p className="text-xs text-muted mt-0.5">{paused ? 'Mint is currently paused' : 'Mint is live'}</p>
          </div>
          <button
            onClick={() => setPaused(!paused)}
            className={`w-12 h-6 rounded-full relative transition-colors duration-300 ${
              paused ? 'bg-surface2 border border-border' : 'bg-success/20 border border-success/30'
            }`}
          >
            <span className={`absolute top-0.5 w-5 h-5 rounded-full transition-all duration-300 ${
              paused ? 'left-0.5 bg-muted-dim' : 'left-[26px] bg-success'
            }`} />
          </button>
        </div>

        <Button variant="primary" size="md" onClick={() => setShowConfirm(true)}>
          <Save size={16} /> Save Changes
        </Button>
      </div>

      {/* Confirm Modal */}
      {showConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-bg/70 backdrop-blur-sm" onClick={() => setShowConfirm(false)} />
          <div className="relative glass-strong rounded-2xl p-6 max-w-sm w-full mx-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-warning/10 flex items-center justify-center">
                <AlertTriangle size={20} className="text-warning" />
              </div>
              <div>
                <h3 className="font-display font-semibold text-text">Confirm Changes</h3>
                <p className="text-xs text-muted">This will update the smart contract.</p>
              </div>
            </div>
            <div className="bg-surface2/50 rounded-xl p-3 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted">Price</span><span className="text-text font-mono">{price} ETH</span></div>
              <div className="flex justify-between"><span className="text-muted">Window</span><span className="text-text font-mono">{mintWindow}h</span></div>
              <div className="flex justify-between"><span className="text-muted">Status</span><span className={paused ? 'text-warning' : 'text-success'}>{paused ? 'Paused' : 'Live'}</span></div>
            </div>
            <div className="flex gap-3">
              <Button variant="ghost" size="md" className="flex-1" onClick={() => setShowConfirm(false)}>Cancel</Button>
              <Button variant="primary" size="md" className="flex-1" onClick={() => setShowConfirm(false)}>Confirm</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
