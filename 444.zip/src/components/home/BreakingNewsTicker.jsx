'use client';

const headlines = [
  'ETH Layer 2 activity surges to all-time high as gas fees drop below 5 gwei',
  'Major NFT marketplace announces zero-fee trading for verified collections',
  'Bitcoin mining difficulty reaches new record — hash rate climbs 12% month-over-month',
  'Polygon zkEVM upgrade unlocks 10x throughput improvement for DeFi protocols',
  'SEC commissioner signals potential regulatory framework for digital assets in 2025',
  'Solana DeFi TVL crosses $12B amid memecoin rally and institutional inflows',
  'Art Blocks curated drops new generative series from award-winning digital artist',
  'Avalanche Foundation deploys $100M ecosystem fund targeting gaming and entertainment',
];

export default function BreakingNewsTicker() {
  // Duplicate headlines for seamless loop
  const doubled = [...headlines, ...headlines];

  return (
    <div className="relative w-full bg-surface border-y border-border-light overflow-hidden z-10">
      <div className="max-w-[1400px] mx-auto flex items-center h-11">
        {/* Left label — fixed, not scrolling */}
        <div className="shrink-0 flex items-center gap-2.5 pl-6 md:pl-8 pr-4 h-full border-r border-border-light bg-surface relative z-10">
          <span className="text-[11px] font-mono font-semibold tracking-wider text-muted uppercase">
            Market Pulse
          </span>
          <span className="flex items-center gap-1 px-2 py-0.5 rounded-pill bg-danger/15 border border-danger/25">
            <span className="w-1.5 h-1.5 rounded-full bg-danger animate-pulse" />
            <span className="text-[10px] font-semibold text-danger uppercase tracking-wide">Breaking</span>
          </span>
        </div>

        {/* Marquee area — masked at edges */}
        <div className="flex-1 overflow-hidden relative h-full flex items-center"
          style={{
            maskImage: 'linear-gradient(to right, transparent 0%, black 48px, black calc(100% - 48px), transparent 100%)',
            WebkitMaskImage: 'linear-gradient(to right, transparent 0%, black 48px, black calc(100% - 48px), transparent 100%)',
          }}
        >
          <div className="flex items-center gap-0 animate-marquee whitespace-nowrap">
            {doubled.map((text, i) => (
              <span key={i} className="flex items-center shrink-0">
                <span className="text-[13px] text-muted hover:text-text transition-colors duration-200 cursor-pointer">
                  {text}
                </span>
                <span className="mx-5 w-1 h-1 rounded-full bg-accent/40 shrink-0" />
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
