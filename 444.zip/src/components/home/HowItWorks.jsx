import { Search, Palette, Zap } from 'lucide-react';

const steps = [
  {
    icon: <Search size={24} />,
    title: 'Discover',
    description: 'Browse curated collections with advanced filtering by rarity, traits, and chain. Every piece has verified provenance.',
    accent: 'from-accent/20 to-accent/5',
    iconColor: 'text-accent',
  },
  {
    icon: <Palette size={24} />,
    title: 'Evaluate',
    description: 'Deep-dive into token metadata, trait distribution, and collection history. Make informed decisions backed by on-chain data.',
    accent: 'from-accent-violet/20 to-accent-violet/5',
    iconColor: 'text-accent-violet',
  },
  {
    icon: <Zap size={24} />,
    title: 'Collect',
    description: 'Mint or purchase through a streamlined wallet-first checkout. Fast transactions with real-time status tracking.',
    accent: 'from-success/20 to-success/5',
    iconColor: 'text-success',
  },
];

export default function HowItWorks() {
  return (
    <section className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-surface/30 to-transparent" />
      <div className="max-w-[1400px] mx-auto px-6 md:px-8 relative">
        <div className="text-center mb-14">
          <h2 className="font-display text-3xl font-bold text-text">How It Works</h2>
          <p className="text-sm text-muted mt-2 max-w-md mx-auto">
            A streamlined process from discovery to collection, built for the modern NFT collector.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {steps.map((step, i) => (
            <div key={i} className="glass-card rounded-card p-7 relative overflow-hidden group animate-fade-in"
                 style={{ animationDelay: `${i * 120}ms` }}>
              {/* Background glow */}
              <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-radial ${step.accent} opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-2xl`} />

              <div className="relative">
                <div className="flex items-center gap-4 mb-4">
                  <div className={`w-12 h-12 rounded-xl bg-surface2 border border-border flex items-center justify-center ${step.iconColor}`}>
                    {step.icon}
                  </div>
                  <span className="text-xs font-mono text-muted-dim">0{i + 1}</span>
                </div>
                <h3 className="font-display text-lg font-semibold text-text mb-2">{step.title}</h3>
                <p className="text-sm text-muted leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
