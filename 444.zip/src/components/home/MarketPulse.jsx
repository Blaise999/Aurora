import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import NewsCard from '@/components/news/NewsCard';
import Button from '@/components/ui/Button';
import { mockNews } from '@/lib/mock/news';

export default function MarketPulse() {
  return (
    <section className="py-20">
      <div className="max-w-[1400px] mx-auto px-6 md:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl font-bold text-text">Market Pulse</h2>
            <p className="text-sm text-muted mt-1.5">Latest from the crypto and NFT ecosystem</p>
          </div>
          <Link href="/news">
            <Button variant="ghost" size="sm">
              View all <ArrowRight size={14} />
            </Button>
          </Link>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {mockNews.slice(0, 4).map((item, i) => (
            <NewsCard key={item.id} item={item} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
