import CollectionCard from '@/components/nft/CollectionCard';
import { mockCollections } from '@/lib/mock/collections';

export default function TrendingCollections() {
  return (
    <section className="py-20">
      <div className="max-w-[1400px] mx-auto px-6 md:px-8">
        <div className="mb-8">
          <h2 className="font-display text-3xl font-bold text-text">Trending Collections</h2>
          <p className="text-sm text-muted mt-1.5">Most active collections in the last 24 hours</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {mockCollections.map((col, i) => (
            <CollectionCard key={col.id} collection={col} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
