'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Menu, X, Wallet, LogOut, User, Loader2 } from 'lucide-react';
import { useConnect, useAccount, useDisconnect } from 'wagmi';
import { useAuth } from '@/hooks/useAuth';
import Button from '@/components/ui/Button';

const navLinks = [
  { label: 'Explore', href: '/explore' },
  { label: 'Mint', href: '/mint' },
  { label: 'News', href: '/news' },
];

export default function Header({ fused = false }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showWalletMenu, setShowWalletMenu] = useState(false);

  const { connectors, connect, isPending: isConnectPending } = useConnect();
  const { address, isConnected } = useAccount();
  const { disconnect } = useDisconnect();
  const { session, isAuthed, login, logout, loading: authLoading } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Auto-SIWE after wallet connects
  useEffect(() => {
    if (isConnected && address && !isAuthed && !authLoading) {
      login();
    }
  }, [isConnected, address, isAuthed, authLoading, login]);

  const isCompact = !fused || scrolled;
  const shortAddr = address ? `${address.slice(0, 6)}…${address.slice(-4)}` : '';

  const handleConnect = () => {
    // Use first available connector (injected = MetaMask/Rabby)
    const connector = connectors[0];
    if (connector) connect({ connector });
  };

  const handleDisconnect = async () => {
    await logout();
    setShowWalletMenu(false);
  };

  return (
    <>
      <header
        className={`
          fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-out
          ${isCompact ? 'glass-strong py-3 shadow-soft' : 'bg-transparent py-5'}
        `}
      >
        <div className="max-w-[1400px] mx-auto px-6 md:px-8 flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent to-accent-violet flex items-center justify-center
              group-hover:shadow-glow transition-shadow duration-300">
              <span className="font-display font-bold text-bg text-sm">A</span>
            </div>
            <span className="font-display font-semibold text-lg tracking-tight text-text">
              Aurora<span className="text-accent">Nft</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-2 text-sm text-muted hover:text-text transition-colors duration-200 rounded-lg hover:bg-white/[0.04]"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Right side — wallet */}
          <div className="flex items-center gap-3">
            {isConnected && address ? (
              <div className="relative">
                <button
                  onClick={() => setShowWalletMenu(!showWalletMenu)}
                  className="hidden md:flex items-center gap-2 px-4 py-2 text-sm rounded-xl glass border border-border hover:border-accent/30 transition-colors"
                >
                  {authLoading ? (
                    <Loader2 size={14} className="animate-spin text-accent" />
                  ) : isAuthed ? (
                    <div className="w-2 h-2 rounded-full bg-success" />
                  ) : (
                    <div className="w-2 h-2 rounded-full bg-warning" />
                  )}
                  <span className="font-mono text-xs text-text">{shortAddr}</span>
                </button>

                {showWalletMenu && (
                  <div className="absolute right-0 top-12 w-52 glass-strong rounded-xl p-2 z-10 shadow-card">
                    {isAuthed && (
                      <Link
                        href={`/profile/${address}`}
                        onClick={() => setShowWalletMenu(false)}
                        className="flex items-center gap-2.5 px-3 py-2 text-sm text-muted hover:text-text rounded-lg hover:bg-white/[0.04] transition-colors"
                      >
                        <User size={14} /> My Profile
                      </Link>
                    )}
                    {!isAuthed && (
                      <button
                        onClick={() => { login(); setShowWalletMenu(false); }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-accent hover:text-accent rounded-lg hover:bg-white/[0.04] transition-colors"
                      >
                        <Wallet size={14} /> Sign In (SIWE)
                      </button>
                    )}
                    <button
                      onClick={handleDisconnect}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-danger hover:text-danger rounded-lg hover:bg-white/[0.04] transition-colors"
                    >
                      <LogOut size={14} /> Disconnect
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Button
                variant="secondary"
                size="sm"
                className="hidden md:flex"
                onClick={handleConnect}
                disabled={isConnectPending}
              >
                {isConnectPending ? (
                  <Loader2 size={14} className="animate-spin" />
                ) : (
                  <Wallet size={16} />
                )}
                Connect
              </Button>
            )}

            <button
              className="md:hidden p-2 text-muted hover:text-text transition-colors"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-bg/80 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="absolute top-0 right-0 w-72 h-full glass-strong p-6 pt-20 flex flex-col gap-2">
            {navLinks.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-3 text-base text-muted hover:text-text rounded-xl hover:bg-white/[0.04] transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            {isAuthed && address && (
              <Link
                href={`/profile/${address}`}
                className="px-4 py-3 text-base text-muted hover:text-text rounded-xl hover:bg-white/[0.04] transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                My Profile
              </Link>
            )}
            <div className="mt-4 pt-4 border-t border-border">
              {isConnected ? (
                <div className="space-y-2">
                  <div className="px-4 py-2 text-xs font-mono text-muted truncate">{shortAddr}</div>
                  {!isAuthed && (
                    <Button variant="primary" size="md" className="w-full" onClick={login} disabled={authLoading}>
                      {authLoading ? <Loader2 size={14} className="animate-spin" /> : <Wallet size={16} />}
                      Sign In
                    </Button>
                  )}
                  <Button variant="danger" size="md" className="w-full" onClick={handleDisconnect}>
                    <LogOut size={16} /> Disconnect
                  </Button>
                </div>
              ) : (
                <Button variant="primary" size="md" className="w-full" onClick={handleConnect} disabled={isConnectPending}>
                  <Wallet size={16} /> Connect Wallet
                </Button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Click-away for wallet menu */}
      {showWalletMenu && (
        <div className="fixed inset-0 z-40" onClick={() => setShowWalletMenu(false)} />
      )}
    </>
  );
}
