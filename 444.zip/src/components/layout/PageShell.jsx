import Header from './Header';
import Footer from './Footer';

export default function PageShell({ children, heroFused = false, noFooter = false }) {
  return (
    <div className="min-h-screen flex flex-col">
      <Header fused={heroFused} />
      <main className={`flex-1 ${heroFused ? '' : 'pt-24'}`}>
        {children}
      </main>
      {!noFooter && <Footer />}
    </div>
  );
}
