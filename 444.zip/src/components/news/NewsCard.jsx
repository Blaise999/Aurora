import { ThumbsUp, ThumbsDown, ExternalLink } from 'lucide-react';
import Badge from '@/components/ui/Badge';
import { getTimeAgo } from '@/lib/mock/news';

const sentimentColor = {
  Hot: 'hot',
  Rising: 'rising',
  Bullish: 'bullish',
  Bearish: 'bearish',
  Important: 'warning',
};

export default function NewsCard({ item, index = 0 }) {
  return (
    <article
      className="group glass-card rounded-card p-5 card-hover animate-fade-in"
      style={{ animationDelay: `${index * 50}ms` }}
    >
      <div className="flex items-start gap-4">
        <div className="flex-1 space-y-2.5">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge color={sentimentColor[item.sentimentTag] || 'default'} dot>
              {item.sentimentTag}
            </Badge>
            <span className="text-[11px] text-muted-dim">{item.source}</span>
            <span className="text-[11px] text-muted-dim">·</span>
            <span className="text-[11px] text-muted-dim">{getTimeAgo(item.publishedAt)}</span>
          </div>

          <h3 className="text-[15px] font-display font-medium text-text leading-snug group-hover:text-accent transition-colors duration-200">
            {item.title}
          </h3>

          <div className="flex items-center gap-3 pt-1">
            {item.tickers.map(ticker => (
              <span key={ticker} className="text-[11px] font-mono text-accent-cyan bg-accent-cyan/10 px-2 py-0.5 rounded-pill">
                ${ticker}
              </span>
            ))}
          </div>
        </div>

        <div className="flex flex-col items-center gap-1.5 shrink-0 pt-1">
          <button className="p-1.5 text-muted-dim hover:text-success transition-colors rounded-lg hover:bg-success/10">
            <ThumbsUp size={14} />
          </button>
          <span className="text-[10px] text-muted-dim font-mono">
            {item.votes ? item.votes.positive - item.votes.negative : 0}
          </span>
          <button className="p-1.5 text-muted-dim hover:text-danger transition-colors rounded-lg hover:bg-danger/10">
            <ThumbsDown size={14} />
          </button>
        </div>
      </div>
    </article>
  );
}
