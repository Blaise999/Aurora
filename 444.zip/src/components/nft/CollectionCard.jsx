import Badge from '@/components/ui/Badge';

export default function CollectionCard({ collection, index = 0 }) {
  return (
    <div
      className="group glass-card rounded-card overflow-hidden card-hover animate-fade-in cursor-pointer"
      style={{ animationDelay: `${index * 80}ms` }}
    >
      <div className="h-32 relative overflow-hidden">
        <img
          src={collection.image}
          alt={collection.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/40 to-transparent" />
      </div>
      <div className="p-5 space-y-3 -mt-6 relative z-10">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-display font-semibold text-text group-hover:text-accent transition-colors duration-200">
              {collection.name}
            </h3>
            <p className="text-xs text-muted-dim mt-0.5">{collection.items.toLocaleString()} items</p>
          </div>
          <Badge color={collection.positive ? 'bullish' : 'bearish'} className="!text-[10px]">
            {collection.change}
          </Badge>
        </div>
        <div className="grid grid-cols-3 gap-3 pt-3 border-t border-border-light">
          <div>
            <p className="text-[10px] text-muted-dim">Floor</p>
            <p className="text-sm text-text font-mono">{collection.floor}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted-dim">Volume</p>
            <p className="text-sm text-text font-mono">{collection.volume}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted-dim">Owners</p>
            <p className="text-sm text-text font-mono">{collection.owners.toLocaleString()}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
