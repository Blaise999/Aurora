'use client';

const variants = {
  primary: 'relative bg-gradient-to-r from-accent to-accent-violet text-bg font-semibold shadow-glow hover:shadow-glow-lg hover:scale-[1.03] active:scale-[0.98]',
  secondary: 'glass border border-border text-text hover:border-accent/30 hover:bg-white/[0.04]',
  ghost: 'text-muted hover:text-text hover:bg-white/[0.04]',
  danger: 'bg-danger/10 text-danger border border-danger/20 hover:bg-danger/20',
};

const sizes = {
  sm: 'px-4 py-2 text-sm rounded-xl',
  md: 'px-6 py-3 text-sm rounded-xl',
  lg: 'px-8 py-3.5 text-base rounded-2xl',
};

export default function Button({
  children, variant = 'primary', size = 'md', className = '', disabled = false, ...props
}) {
  return (
    <button
      className={`
        inline-flex items-center justify-center gap-2 font-body font-medium
        transition-all duration-300 ease-out
        disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:scale-100
        ${variants[variant]} ${sizes[size]} ${className}
      `}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  );
}
