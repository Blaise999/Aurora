// lib/alchemy/nft-normalize.ts
type UiNft = {
  id: string;                 // used by NFTGrid key + Link
  contractAddress: string;
  tokenId: string;
  name: string;
  chain: string;
  collectionName: string;
  hasMedia: boolean;
  normalized_metadata: { image?: string };
  price?: string;             // optional (Alchemy doesn't give listing price)
  lastSale?: string;          // optional
};

function ipfsToHttp(url?: string) {
  if (!url) return undefined;
  if (url.startsWith("http://") || url.startsWith("https://")) return url;
  if (url.startsWith("ipfs://")) return url.replace("ipfs://", "https://ipfs.io/ipfs/");
  return url;
}

function pickImage(nft: any) {
  // v3 payloads often have media[0].gateway or metadata.image
  return ipfsToHttp(
    nft?.media?.[0]?.gateway ||
    nft?.image?.cachedUrl ||
    nft?.metadata?.image ||
    nft?.raw?.metadata?.image ||
    nft?.tokenUri?.gateway
  );
}

function normalizeTokenId(tokenId: any) {
  // tokenId can come as hex or decimal; keep as string
  if (tokenId === null || tokenId === undefined) return "";
  return String(tokenId);
}

export function alchemyOwnedToUi(payload: any, chainLabel = "Ethereum"): UiNft[] {
  const list = payload?.ownedNfts ?? payload?.nfts ?? [];
  return list.map((nft: any) => {
    const contractAddress = nft?.contract?.address || nft?.contractAddress || "";
    const tokenId = normalizeTokenId(nft?.tokenId);

    const image = pickImage(nft);
    const name = nft?.name || (tokenId ? `#${tokenId}` : "Untitled");
    const collectionName =
      nft?.contractMetadata?.name ||
      nft?.collection?.name ||
      nft?.contract?.name ||
      "Collection";

    // Make a URL-safe id for your Link(`/nft/${nft.id}`)
    // You can later decode it on the details page.
const id = `${contractAddress}_${tokenId}`.replace(/:/g, "_");

    return {
      id,
      contractAddress,
      tokenId,
      name,
      chain: chainLabel,
      collectionName,
      hasMedia: Boolean(image),
      normalized_metadata: { image },
      // price/lastSale are NOT reliably provided by Alchemy for listings
      price: "—",
      lastSale: "—",
    };
  });
}