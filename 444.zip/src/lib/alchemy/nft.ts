// lib/alchemy/nft.ts
export type AlchemyNft = {
  contractAddress: string;
  tokenId: string;
  name?: string;
  description?: string;
  image?: string;
  collectionName?: string;
  raw?: any;
};

function requireEnv(name: string) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

function ipfsToHttp(url?: string) {
  if (!url) return undefined;

  // Already https/http
  if (url.startsWith("http://") || url.startsWith("https://")) return url;

  // ipfs://CID/path -> https://ipfs.io/ipfs/CID/path
  if (url.startsWith("ipfs://")) {
    return url.replace("ipfs://", "https://ipfs.io/ipfs/");
  }

  return url;
}

function pickImage(nft: any) {
  // Alchemy often returns a fast cached CDN link in media[].gateway when available
  // (may look like nft-cdn.alchemy.com/...) :contentReference[oaicite:4]{index=4}
  const gateway =
    nft?.media?.[0]?.gateway ||
    nft?.image?.cachedUrl ||
    nft?.metadata?.image ||
    nft?.raw?.metadata?.image ||
    nft?.tokenUri?.gateway;

  return ipfsToHttp(gateway);
}

export async function alchemyGet(path: string, searchParams?: Record<string, string>) {
  const apiKey = requireEnv("ALCHEMY_API_KEY");
  const base = requireEnv("ALCHEMY_NFT_BASE_URL"); // e.g. https://eth-mainnet.g.alchemy.com/nft/v3

  const url = new URL(`${base}/${apiKey}/${path}`);
  if (searchParams) {
    for (const [k, v] of Object.entries(searchParams)) {
      if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, v);
    }
  }

  const res = await fetch(url.toString(), {
    // Cache a bit on the server to keep your app fast and reduce API usage
    next: { revalidate: 30 },
    headers: { accept: "application/json" },
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Alchemy ${res.status}: ${text || res.statusText}`);
  }

  return res.json();
}

export function normalizeOwnedNfts(payload: any): AlchemyNft[] {
  const list = payload?.ownedNfts ?? payload?.nfts ?? [];
  return list.map((nft: any) => ({
    contractAddress: nft?.contract?.address || nft?.contractAddress || "",
    tokenId: nft?.tokenId?.toString?.() ?? String(nft?.tokenId ?? ""),
    name: nft?.name,
    description: nft?.description,
    image: pickImage(nft),
    collectionName: nft?.contractMetadata?.name || nft?.collection?.name,
    raw: nft,
  }));
}

export function normalizeSingleNft(payload: any): AlchemyNft {
  const nft = payload?.nft ?? payload;
  return {
    contractAddress: nft?.contract?.address || nft?.contractAddress || "",
    tokenId: nft?.tokenId?.toString?.() ?? String(nft?.tokenId ?? ""),
    name: nft?.name,
    description: nft?.description,
    image: pickImage(nft),
    collectionName: nft?.contractMetadata?.name || nft?.collection?.name,
    raw: nft,
  };
}