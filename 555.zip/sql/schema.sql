-- AuroraNft — Supabase Schema (Full)
-- Run in Supabase SQL Editor

-- ═══════════════════════════════════════════════════
-- 1) EXISTING TABLES
-- ═══════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS nft_metadata_cache (
  id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  chain_id         int NOT NULL,
  contract_address text NOT NULL,
  token_id         text NOT NULL,
  name             text,
  description      text,
  image_url        text,
  attributes       jsonb DEFAULT '[]'::jsonb,
  updated_at       timestamptz DEFAULT now(),
  UNIQUE (chain_id, contract_address, token_id)
);

CREATE TABLE IF NOT EXISTS user_nfts (
  id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  chain_id         int NOT NULL,
  contract_address text NOT NULL,
  token_id         text NOT NULL,
  owner_address    text NOT NULL,
  minter_address   text,
  tx_hash          text NOT NULL,
  minted_at        timestamptz DEFAULT now(),
  status           text NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending','confirmed','failed')),
  UNIQUE (chain_id, contract_address, token_id),
  UNIQUE (tx_hash)
);

CREATE INDEX IF NOT EXISTS idx_user_nfts_owner ON user_nfts (owner_address);
CREATE INDEX IF NOT EXISTS idx_user_nfts_status ON user_nfts (status);
CREATE INDEX IF NOT EXISTS idx_metadata_lookup ON nft_metadata_cache (chain_id, contract_address, token_id);


-- ═══════════════════════════════════════════════════
-- 2) SITE SETTINGS (minting fee, global config)
-- ═══════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS site_settings (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  key         text NOT NULL UNIQUE,
  value       text NOT NULL,
  updated_at  timestamptz DEFAULT now(),
  updated_by  text
);

INSERT INTO site_settings (key, value) VALUES
  ('minting_fee', '0.002'),
  ('sale_active', 'true'),
  ('max_per_wallet', '10'),
  ('mint_window_hours', '72'),
  ('ntfy_topic', 'aurora-nft-admin')
ON CONFLICT (key) DO NOTHING;


-- ═══════════════════════════════════════════════════
-- 3) NFT PRICES (per-NFT custom pricing by admin)
-- ═══════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS nft_prices (
  id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  nft_id           text NOT NULL,
  contract_address text,
  token_id         text,
  name             text NOT NULL,
  price_eth        numeric(18,8) NOT NULL DEFAULT 0.002,
  minting_fee_eth  numeric(18,8) NOT NULL DEFAULT 0.001,
  is_listed        boolean DEFAULT true,
  updated_at       timestamptz DEFAULT now(),
  updated_by       text,
  UNIQUE (nft_id)
);

CREATE INDEX IF NOT EXISTS idx_nft_prices_listed ON nft_prices (is_listed);

INSERT INTO nft_prices (nft_id, name, price_eth, minting_fee_eth) VALUES
  ('0',  'Celestial Fragment #1000',  0.850, 0.002),
  ('1',  'Void Resonance #1001',      1.200, 0.002),
  ('2',  'Temporal Echo #1002',        0.450, 0.002),
  ('3',  'Quantum Whisper #1003',      2.100, 0.002),
  ('4',  'Nebula Core #1004',          0.650, 0.002),
  ('5',  'Phantom Signal #1005',       1.800, 0.002),
  ('6',  'Astral Prism #1006',         0.300, 0.002),
  ('7',  'Dark Matter Bloom #1007',    1.500, 0.002),
  ('8',  'Ether Cascade #1008',        0.750, 0.002),
  ('9',  'Mythic Shard #1009',         2.400, 0.002),
  ('10', 'Genesis Pulse #1010',        0.550, 0.002),
  ('11', 'Shadow Lattice #1011',       1.100, 0.002),
  ('12', 'Drift Protocol #1012',       0.400, 0.002),
  ('13', 'Neon Relic #1013',           1.950, 0.002),
  ('14', 'Spectral Drift #1014',       0.600, 0.002),
  ('15', 'Arcane Nexus #1015',         1.350, 0.002),
  ('16', 'Binary Sunset #1016',        0.500, 0.002),
  ('17', 'Crystal Matrix #1017',       2.200, 0.002),
  ('18', 'Flux Memory #1018',          0.700, 0.002),
  ('19', 'Neural Bloom #1019',         1.650, 0.002),
  ('20', 'Pixel Requiem #1020',        0.350, 0.002),
  ('21', 'Sonic Artifact #1021',       1.450, 0.002),
  ('22', 'Tidal Node #1022',           0.900, 0.002),
  ('23', 'Umbral Seed #1023',          2.000, 0.002)
ON CONFLICT (nft_id) DO NOTHING;


-- ═══════════════════════════════════════════════════
-- 4) VISITOR LOGS (IP tracking + geolocation)
-- ═══════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS visitor_logs (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  ip_address  text NOT NULL,
  country     text,
  region      text,
  city        text,
  latitude    numeric(10,6),
  longitude   numeric(10,6),
  isp         text,
  user_agent  text,
  page_path   text DEFAULT '/',
  referrer    text,
  visited_at  timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_visitor_logs_ip ON visitor_logs (ip_address);
CREATE INDEX IF NOT EXISTS idx_visitor_logs_time ON visitor_logs (visited_at DESC);


-- ═══════════════════════════════════════════════════
-- 5) SUPPORT CHAT (live support messages)
-- ═══════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS support_conversations (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  visitor_id    text NOT NULL UNIQUE,
  visitor_name  text DEFAULT 'Anonymous',
  visitor_email text,
  wallet_address text,
  status        text NOT NULL DEFAULT 'open'
                  CHECK (status IN ('open','resolved','archived')),
  created_at    timestamptz DEFAULT now(),
  updated_at    timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_support_convos_status ON support_conversations (status);
CREATE INDEX IF NOT EXISTS idx_support_convos_updated ON support_conversations (updated_at DESC);

CREATE TABLE IF NOT EXISTS support_messages (
  id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  conversation_id bigint NOT NULL REFERENCES support_conversations(id) ON DELETE CASCADE,
  sender_type     text NOT NULL CHECK (sender_type IN ('visitor','admin')),
  sender_name     text DEFAULT 'Anonymous',
  message         text NOT NULL,
  created_at      timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_support_msgs_convo ON support_messages (conversation_id, created_at);


-- ═══════════════════════════════════════════════════
-- 6) ADMIN NOTIFICATIONS LOG
-- ═══════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS admin_notifications (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  type        text NOT NULL CHECK (type IN ('visitor','support','mint','system')),
  title       text NOT NULL,
  body        text,
  metadata    jsonb DEFAULT '{}'::jsonb,
  is_read     boolean DEFAULT false,
  created_at  timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_admin_notifs_unread ON admin_notifications (is_read, created_at DESC);


-- ═══════════════════════════════════════════════════
-- 7) ROW LEVEL SECURITY
-- ═══════════════════════════════════════════════════

ALTER TABLE nft_metadata_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_nfts ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE nft_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE visitor_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE support_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE support_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "metadata_read_all" ON nft_metadata_cache FOR SELECT USING (true);
CREATE POLICY "user_nfts_read_all" ON user_nfts FOR SELECT USING (true);
CREATE POLICY "nft_prices_read_all" ON nft_prices FOR SELECT USING (true);
CREATE POLICY "settings_read_all" ON site_settings FOR SELECT USING (true);
CREATE POLICY "support_convos_read" ON support_conversations FOR SELECT USING (true);
CREATE POLICY "support_msgs_read" ON support_messages FOR SELECT USING (true);
CREATE POLICY "visitor_logs_no_anon" ON visitor_logs FOR SELECT USING (false);
CREATE POLICY "admin_notifs_no_anon" ON admin_notifications FOR SELECT USING (false);

CREATE POLICY "metadata_no_anon_write" ON nft_metadata_cache FOR INSERT WITH CHECK (false);
CREATE POLICY "user_nfts_no_anon_write" ON user_nfts FOR INSERT WITH CHECK (false);
CREATE POLICY "settings_no_anon_write" ON site_settings FOR INSERT WITH CHECK (false);
CREATE POLICY "nft_prices_no_anon_write" ON nft_prices FOR INSERT WITH CHECK (false);
CREATE POLICY "visitor_logs_insert_service" ON visitor_logs FOR INSERT WITH CHECK (false);
CREATE POLICY "support_convos_insert" ON support_conversations FOR INSERT WITH CHECK (false);
CREATE POLICY "support_msgs_insert" ON support_messages FOR INSERT WITH CHECK (false);
CREATE POLICY "admin_notifs_insert" ON admin_notifications FOR INSERT WITH CHECK (false);


-- ═══════════════════════════════════════════════════
-- 8) REALTIME (enable for live support chat)
-- ═══════════════════════════════════════════════════

ALTER PUBLICATION supabase_realtime ADD TABLE support_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE support_conversations;
ALTER PUBLICATION supabase_realtime ADD TABLE visitor_logs;
ALTER PUBLICATION supabase_realtime ADD TABLE admin_notifications;
