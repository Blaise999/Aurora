import { NextResponse } from 'next/server';
import { getSupabase } from '@/lib/db/supabase';

export async function GET() {
  try {
    const sb = getSupabase();
    const { data, error } = await sb.from('nft_prices').select('*').order('nft_id');
    if (error) throw error;
    return NextResponse.json({ prices: data || [] });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req) {
  try {
    const body = await req.json();
    const { nft_id, price_eth, minting_fee_eth, is_listed, adminWallet } = body;
    if (!nft_id) return NextResponse.json({ error: 'Missing nft_id' }, { status: 400 });

    const sb = getSupabase();
    const updates = { updated_at: new Date().toISOString(), updated_by: adminWallet || null };
    if (price_eth !== undefined) updates.price_eth = price_eth;
    if (minting_fee_eth !== undefined) updates.minting_fee_eth = minting_fee_eth;
    if (is_listed !== undefined) updates.is_listed = is_listed;

    const { data, error } = await sb
      .from('nft_prices')
      .update(updates)
      .eq('nft_id', nft_id)
      .select()
      .single();
    if (error) throw error;
    return NextResponse.json({ price: data });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
