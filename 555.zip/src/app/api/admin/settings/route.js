import { NextResponse } from 'next/server';
import { getSupabase } from '@/lib/db/supabase';

export async function GET() {
  try {
    const sb = getSupabase();
    const { data, error } = await sb.from('site_settings').select('*');
    if (error) throw error;
    const settings = {};
    (data || []).forEach((row) => { settings[row.key] = row.value; });
    return NextResponse.json({ settings });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req) {
  try {
    const body = await req.json();
    const { key, value, adminWallet } = body;
    if (!key || value === undefined) {
      return NextResponse.json({ error: 'Missing key or value' }, { status: 400 });
    }
    const sb = getSupabase();
    const { data, error } = await sb
      .from('site_settings')
      .upsert({ key, value: String(value), updated_at: new Date().toISOString(), updated_by: adminWallet || null }, { onConflict: 'key' })
      .select()
      .single();
    if (error) throw error;
    return NextResponse.json({ setting: data });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
