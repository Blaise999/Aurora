'use client';
import Link from 'next/link';
import { ArrowRight, Sparkles } from 'lucide-react';
import Button from '@/components/ui/Button';

export default function CallToAction() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-radial from-accent/[0.08] via-accent-violet/[0.04] to-transparent rounded-full blur-3xl" />
      </div>
      <div className="max-w-[1400px] mx-auto px-6 md:px-8 relative">
        <div className="glass-card rounded-[28px] p-10 sm:p-16 text-center relative overflow-hidden">
          <div className="absolute inset-0 rounded-[28px] p-px bg-gradient-to-r from-accent/40 via-accent-violet/40 to-accent/40 -z-10" />
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
              <Sparkles size={20} className="text-accent" />
            </div>
          </div>
          <h2 className="font-display text-3xl sm:text-5xl font-bold text-text mb-4 leading-tight">
            Ready to start your <span className="gradient-text">collection</span>?
          </h2>
          <p className="text-base sm:text-lg text-muted max-w-lg mx-auto mb-8 leading-relaxed">
            Join thousands of collectors minting unique digital artifacts with verified on-chain provenance.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/mint"><Button variant="primary" size="lg">Start Minting <ArrowRight size={18} /></Button></Link>
            <Link href="/explore"><Button variant="secondary" size="lg">Browse Collection</Button></Link>
          </div>
          <div className="flex items-center justify-center gap-6 sm:gap-10 mt-10 pt-8 border-t border-border-light">
            {[['4,237', 'Minted'], ['1,892', 'Collectors'], ['339 ETH', 'Volume']].map(([val, label]) => (
              <div key={label} className="text-center">
                <p className="font-display font-bold text-lg sm:text-xl text-text">{val}</p>
                <p className="text-[11px] text-muted-dim mt-0.5">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
