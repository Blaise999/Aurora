'use client';
import { useEffect, useState, useRef } from 'react';
import { Flame, Users, Zap, TrendingUp } from 'lucide-react';

function AnimatedNumber({ target, duration = 2000, prefix = '', suffix = '' }) {
  const [current, setCurrent] = useState(0);
  const ref = useRef(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const start = Date.now();
          const tick = () => {
            const elapsed = Date.now() - start;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCurrent(Math.floor(eased * target));
            if (progress < 1) requestAnimationFrame(tick);
          };
          tick();
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target, duration]);

  return (
    <span ref={ref} className="font-display font-bold text-2xl sm:text-3xl text-text">
      {prefix}{current.toLocaleString()}{suffix}
    </span>
  );
}

export default function LiveStats() {
  const stats = [
    { label: 'NFTs Minted', value: 4237, icon: Flame, color: 'text-accent', suffix: '' },
    { label: 'Active Wallets', value: 1892, icon: Users, color: 'text-accent-violet', suffix: '' },
    { label: 'Total Volume', value: 339, icon: TrendingUp, color: 'text-success', suffix: ' ETH' },
    { label: 'Avg Mint Speed', value: 2, icon: Zap, color: 'text-warning', suffix: '.3s' },
  ];

  return (
    <section className="relative py-8 -mt-12 z-10">
      <div className="max-w-[1400px] mx-auto px-6 md:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="glass-card rounded-card p-5 sm:p-6 text-center relative overflow-hidden group hover:border-white/10 transition-all duration-300">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-32 bg-gradient-radial from-accent/[0.06] to-transparent rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative">
                  <Icon size={20} className={'mx-auto mb-3 ' + stat.color} />
                  <AnimatedNumber target={stat.value} suffix={stat.suffix} duration={1800 + i * 300} />
                  <p className="text-xs text-muted mt-1.5">{stat.label}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
