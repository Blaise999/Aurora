import { NextResponse } from "next/server";
import { getSupabase } from "@/lib/db/supabase";
import { sendNtfyNotification } from "@/lib/ntfy";

export const runtime = "nodejs";

/**
 * POST /api/nft/buy
 * Body: { txHash, nftId, contractAddress, tokenId, pricePaid, name,
 *         ownerAddress, minterAddress, imageUrl, description, attributes,
 *         priceEth, mintingFeeEth }
 *
 * Called AFTER the user's wallet tx confirms on-chain.
 * Saves the NFT purchase to user_nfts + metadata cache.
 * Sends ntfy notification to admin.
 *
 * Accepts wallet address from session OR from request body (for compat).
 */
export async function POST(req: Request) {
  try {
    // Try session first, fall back to body.ownerAddress
    let wallet: string | null = null;
    try {
      const { getSession } = await import("@/lib/auth/session");
      wallet = await getSession();
    } catch {
      // session module may fail if SESSION_SECRET not set
    }

    const body = await req.json();
    const {
      txHash,
      nftId,
      contractAddress,
      tokenId,
      pricePaid,
      priceEth,
      mintingFeeEth,
      name,
      description,
      imageUrl,
      attributes,
      ownerAddress,
      minterAddress,
    } = body;

    // Use session wallet if available, otherwise body
    wallet = wallet || ownerAddress || "";
    if (!wallet) {
      return NextResponse.json({ error: "No wallet address" }, { status: 401 });
    }
    if (!txHash) {
      return NextResponse.json({ error: "Missing txHash" }, { status: 400 });
    }

    const sb = getSupabase();
    const chainId = parseInt(process.env.NEXT_PUBLIC_CHAIN_ID || "84532", 10);
    const addr = (
      contractAddress ||
      process.env.NEXT_PUBLIC_AURORA_CONTRACT ||
      ""
    ).toLowerCase();
    const tid = tokenId || nftId || "0";
    const totalPaid = pricePaid || priceEth || "0";

    // 1. Upsert into user_nfts
    const { error: nftErr } = await sb.from("user_nfts").upsert(
      {
        chain_id: chainId,
        contract_address: addr,
        token_id: tid,
        owner_address: wallet.toLowerCase(),
        minter_address: (minterAddress || wallet).toLowerCase(),
        tx_hash: txHash.toLowerCase(),
        minted_at: new Date().toISOString(),
        status: "confirmed",
      },
      { onConflict: "tx_hash" }
    );
    if (nftErr && !nftErr.message?.includes("duplicate")) {
      console.error("user_nfts upsert error:", nftErr);
    }

    // 2. Cache metadata
    if (name || imageUrl) {
      await sb.from("nft_metadata_cache").upsert(
        {
          chain_id: chainId,
          contract_address: addr,
          token_id: tid,
          name: name || `NFT #${tid}`,
          description: description || "Purchased via AuroraNft",
          image_url: imageUrl || "",
          attributes: attributes || [],
          updated_at: new Date().toISOString(),
        },
        { onConflict: "chain_id,contract_address,token_id" }
      );
    }

    // 3. Log admin notification in DB
    await sb.from("admin_notifications").insert({
      type: "mint",
      title: "New Purchase!",
      body: `NFT #${tid} (${name || "—"}) bought by ${wallet.slice(0, 10)}… for ${totalPaid} ETH`,
      metadata: { txHash, nftId, tokenId: tid, wallet, pricePaid: totalPaid },
    });

    // 4. Push ntfy notification to admin phone
    await sendNtfyNotification({
      title: "💰 New NFT Purchase!",
      message: `NFT #${tid} (${name || "—"}) bought by ${wallet}\nPrice: ${totalPaid} ETH\nTx: ${txHash}`,
      priority: "high",
      tags: ["money_with_wings", "tada"],
      click: "/admin",
    });

    return NextResponse.json({
      ok: true,
      success: true,
      tokenId: tid,
      txHash,
    });
  } catch (e: any) {
    console.error("[/api/nft/buy]", e);

    // Send failure notification
    try {
      await sendNtfyNotification({
        title: "❌ Purchase Failed",
        message: `Error: ${e?.message || "Unknown"}`,
        priority: "high",
        tags: ["warning"],
        click: "/admin",
      });
    } catch {}

    return NextResponse.json(
      { error: e?.message || "Failed" },
      { status: 500 }
    );
  }
}
