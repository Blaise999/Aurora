import { NextResponse } from "next/server";
import { LOCAL_NFTS } from "@/lib/constants";

export const runtime = "nodejs";

// In-memory cache for trending NFTs (re-fetched from Alchemy once/day)
let _cache = { nfts: null, fetchedAt: 0 };
const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours

/**
 * GET /api/nft/trending?limit=12
 * Returns trending/featured NFTs from Alchemy, cached for 24h.
 * Falls back to local NFTs if Alchemy fails.
 */
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const limit = parseInt(searchParams.get("limit") || "12");

  const now = Date.now();

  // Try cache first
  if (_cache.nfts && now - _cache.fetchedAt < CACHE_TTL) {
    return NextResponse.json({
      nfts: _cache.nfts.slice(0, limit),
      source: "alchemy-cached",
    });
  }

  // Fetch from Alchemy (server-side)
  try {
    const apiKey = process.env.ALCHEMY_API_KEY || process.env.NEXT_PUBLIC_ALCHEMY_API_KEY;
    const chainId = parseInt(process.env.NEXT_PUBLIC_CHAIN_ID || "84532", 10);

    if (!apiKey) throw new Error("No Alchemy API key");

    // Map chainId to Alchemy host
    const hostMap = {
      1: "eth-mainnet", 11155111: "eth-sepolia",
      8453: "base-mainnet", 84532: "base-sepolia",
      137: "polygon-mainnet",
    };
    const host = hostMap[chainId] || "base-sepolia";

    // Try a known collection or use searchContractMetadata
    const contractAddress =
      process.env.NEXT_PUBLIC_AURORA_CONTRACT ||
      "0xd4307e0acd12cf46fd6cf93bc264f5d5d1598792"; // sample Base collection

    const url = `https://${host}.g.alchemy.com/nft/v3/${apiKey}/getNFTsForContract?contractAddress=${contractAddress}&withMetadata=true&limit=50`;
    const res = await fetch(url, {
      headers: { accept: "application/json" },
      next: { revalidate: 3600 }, // Next.js cache: 1h
    });

    if (!res.ok) throw new Error(`Alchemy ${res.status}`);
    const data = await res.json();

    const nfts = (data?.nfts ?? []).map((nft) => {
      const image =
        nft?.image?.cachedUrl ||
        nft?.image?.thumbnailUrl ||
        nft?.image?.pngUrl ||
        nft?.image?.originalUrl ||
        nft?.raw?.metadata?.image ||
        "";
      const resolvedImage = image.startsWith("ipfs://")
        ? image.replace("ipfs://", "https://ipfs.io/ipfs/")
        : image;

      return {
        contractAddress: nft?.contract?.address || contractAddress,
        tokenId: String(nft?.tokenId ?? ""),
        name: nft?.name || nft?.contract?.name || `#${nft?.tokenId}`,
        description: nft?.description || "",
        image: resolvedImage,
        collection:
          nft?.contract?.name ||
          nft?.contract?.openSeaMetadata?.collectionName ||
          "Unknown Collection",
        attributes: nft?.raw?.metadata?.attributes || [],
        tokenType: nft?.tokenType || "ERC721",
        source: "alchemy",
      };
    });

    if (nfts.length > 0) {
      _cache = { nfts, fetchedAt: now };
      return NextResponse.json({
        nfts: nfts.slice(0, limit),
        source: "alchemy",
      });
    }
  } catch (err) {
    console.error("[trending] Alchemy fetch error:", err.message);
  }

  // Fallback to local NFTs
  const shuffled = [...LOCAL_NFTS].sort(() => Math.random() - 0.5).slice(0, limit);
  return NextResponse.json({ nfts: shuffled, source: "local" });
}
