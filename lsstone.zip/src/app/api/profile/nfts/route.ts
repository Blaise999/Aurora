import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth/session";
import { getSupabase } from "@/lib/db/supabase";

export const runtime = "nodejs";

/**
 * GET /api/profile/nfts
 * Returns ALL the session user's NFTs from DB (minted + bought).
 */
export async function GET() {
  try {
    const wallet = await getSession();
    if (!wallet) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const supabase = getSupabase();

    const { data: nfts, error } = await supabase
      .from("user_nfts")
      .select(`
        chain_id,
        contract_address,
        token_id,
        owner_address,
        tx_hash,
        minted_at,
        status
      `)
      .eq("owner_address", wallet.toLowerCase())
      .eq("status", "confirmed")
      .order("minted_at", { ascending: false });

    if (error) throw error;

    // Enrich with metadata cache
    const enriched = [];
    for (const nft of nfts || []) {
      const { data: meta } = await supabase
        .from("nft_metadata_cache")
        .select("name, description, image_url, attributes")
        .eq("chain_id", nft.chain_id)
        .eq("contract_address", nft.contract_address)
        .eq("token_id", nft.token_id)
        .maybeSingle();

      // Also try to get price data
      const { data: priceData } = await supabase
        .from("nft_prices")
        .select("price_eth")
        .eq("nft_id", nft.token_id)
        .maybeSingle();

      enriched.push({
        id: `${nft.contract_address}_${nft.token_id}`,
        contractAddress: nft.contract_address,
        tokenId: nft.token_id,
        name: meta?.name || `NFT #${nft.token_id}`,
        chain: nft.chain_id === 8453 ? "Base" : "Base Sepolia",
        collectionName: "AuroraNft",
        hasMedia: Boolean(meta?.image_url),
        normalized_metadata: { image: meta?.image_url },
        price: priceData?.price_eth ? `${priceData.price_eth} ETH` : "—",
        lastSale: "—",
        txHash: nft.tx_hash,
        mintedAt: nft.minted_at,
      });
    }

    return NextResponse.json({ nfts: enriched });
  } catch (e: any) {
    console.error("Profile nfts error:", e);
    return NextResponse.json(
      { error: e?.message || "Failed" },
      { status: 500 }
    );
  }
}
