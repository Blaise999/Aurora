"use client";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useNftMetadata, useSettings, useTrendingNfts } from "@/hooks/useNfts";
import { resolveImage, formatEth, isAuroraNft } from "@/lib/utils";
import { AURORA_CONTRACT } from "@/lib/constants";
import MintPanel from "@/components/MintPanel";
import NftCard from "@/components/NftCard";
import NftCardSkeleton from "@/components/NftCardSkeleton";

function MintPageContent() {
  const searchParams = useSearchParams();
  const contractParam = searchParams.get("contract");
  const tokenIdParam = searchParams.get("tokenId");
  const nftIdParam = searchParams.get("nftId");

  // Determine mode
  const isSelectedMode = !!(contractParam || nftIdParam);

  // Fetch selected NFT if in selected mode
  const { nft: selectedNft, loading: nftLoading } = useNftMetadata(
    isSelectedMode ? contractParam : null,
    isSelectedMode ? tokenIdParam : null,
    isSelectedMode ? nftIdParam : null
  );

  // Fetch site settings
  const { settings, loading: settingsLoading } = useSettings();

  // Fetch related NFTs for sidebar / collection grid
  const { nfts: relatedNfts, loading: relatedLoading } = useTrendingNfts(12);

  // Determine if mintable from our contract
  const mintable = selectedNft
    ? isAuroraNft(selectedNft, AURORA_CONTRACT) || selectedNft.isLocal
    : true;

  // Active NFT to display
  const displayNft = selectedNft;
  const isLoading = nftLoading || settingsLoading;

  // Image zoom state
  const [imgZoomed, setImgZoomed] = useState(false);

  return (
    <div className="min-h-screen">
      {/* Background effects */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-accent/3 rounded-full blur-[200px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-accent-violet/4 rounded-full blur-[180px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-xs text-muted-dim mb-6 sm:mb-8">
          <Link href="/" className="hover:text-accent transition-colors">Home</Link>
          <span>/</span>
          <Link href="/explore" className="hover:text-accent transition-colors">Explore</Link>
          <span>/</span>
          <span className="text-text">
            {isSelectedMode ? (displayNft?.name || "Loading...") : "Mint"}
          </span>
        </nav>

        {isSelectedMode && displayNft ? (
          /* ════ SELECTED NFT MODE ════ */
          <div className="grid lg:grid-cols-5 gap-6 lg:gap-10">
            {/* Left — NFT Image + Details (3 cols) */}
            <div className="lg:col-span-3 space-y-6">
              {/* Hero Image */}
              <div
                className={`
                  relative rounded-card overflow-hidden border border-border-light shadow-card
                  ${imgZoomed ? "cursor-zoom-out" : "cursor-zoom-in"}
                `}
                onClick={() => setImgZoomed(!imgZoomed)}
              >
                <div className={`relative ${imgZoomed ? "aspect-auto min-h-[500px]" : "aspect-square"} transition-all duration-500`}>
                  <Image
                    src={resolveImage(displayNft)}
                    alt={displayNft.name || "NFT"}
                    fill
                    className={`object-contain transition-transform duration-500 ${imgZoomed ? "scale-110" : ""}`}
                    sizes="(max-width: 1024px) 100vw, 60vw"
                    priority
                  />
                </div>
                {/* Corner badge */}
                <div className="absolute top-4 left-4 px-3 py-1.5 rounded-pill bg-surface/80 backdrop-blur-sm border border-border-light text-xs font-display font-semibold">
                  {displayNft.collection || "Aurora Collection"}
                </div>
              </div>

              {/* Info panels */}
              <div className="space-y-4">
                {/* Title + Description */}
                <div className="rounded-card bg-surface2 border border-border-light p-5 sm:p-6">
                  <h1 className="font-display font-extrabold text-2xl sm:text-3xl mb-3">
                    {displayNft.name}
                  </h1>
                  <p className="text-sm text-muted leading-relaxed">
                    {displayNft.description || "A unique digital collectible from the Aurora NFT collection."}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mt-4">
                    <span className="px-3 py-1 rounded-pill bg-accent/10 text-xs text-accent font-medium border border-accent/20">
                      {displayNft.tokenType || "ERC-721"}
                    </span>
                    {displayNft.source === "alchemy" && (
                      <span className="px-3 py-1 rounded-pill bg-accent-violet/10 text-xs text-accent-violet font-medium border border-accent-violet/20">
                        On-chain
                      </span>
                    )}
                    {displayNft.isLocal && (
                      <span className="px-3 py-1 rounded-pill bg-success/10 text-xs text-success font-medium border border-success/20">
                        Aurora Collection
                      </span>
                    )}
                    {!mintable && (
                      <span className="px-3 py-1 rounded-pill bg-warning/10 text-xs text-warning font-medium border border-warning/20">
                        External NFT
                      </span>
                    )}
                  </div>
                </div>

                {/* Details grid */}
                <div className="rounded-card bg-surface2 border border-border-light p-5 sm:p-6">
                  <h3 className="font-display font-semibold text-sm uppercase tracking-wider text-muted mb-4">
                    Details
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: "Token ID", value: displayNft.tokenId || "—" },
                      {
                        label: "Contract",
                        value: displayNft.contractAddress
                          ? `${displayNft.contractAddress.slice(0, 6)}...${displayNft.contractAddress.slice(-4)}`
                          : "—",
                      },
                      { label: "Collection", value: displayNft.collection || "Aurora" },
                      { label: "Chain", value: "Base" },
                    ].map((item) => (
                      <div key={item.label} className="space-y-1">
                        <p className="text-xs text-muted-dim">{item.label}</p>
                        <p className="text-sm font-mono">{item.value}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Attributes */}
                {displayNft.attributes?.length > 0 && (
                  <div className="rounded-card bg-surface2 border border-border-light p-5 sm:p-6">
                    <h3 className="font-display font-semibold text-sm uppercase tracking-wider text-muted mb-4">
                      Attributes
                    </h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {displayNft.attributes.map((attr, i) => (
                        <div
                          key={i}
                          className="rounded-xl bg-accent/5 border border-accent/10 p-3 text-center"
                        >
                          <p className="text-[10px] text-accent uppercase tracking-wider mb-1">
                            {attr.trait_type}
                          </p>
                          <p className="text-sm font-semibold truncate">{attr.value}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right — Mint Panel + Related (2 cols) */}
            <div className="lg:col-span-2 space-y-6">
              <div className="lg:sticky lg:top-24">
                <MintPanel
                  nft={displayNft}
                  pricing={selectedNft}
                  siteSettings={settings}
                  loading={isLoading}
                  isMintable={mintable}
                />

                {/* Related NFTs */}
                {relatedNfts.length > 0 && (
                  <div className="mt-6">
                    <h3 className="font-display font-semibold text-sm uppercase tracking-wider text-muted mb-4">
                      More to Explore
                    </h3>
                    <div className="grid grid-cols-2 gap-3">
                      {relatedNfts.slice(0, 4).map((nft, i) => (
                        <NftCard key={`related-${nft.contractAddress}-${nft.tokenId}-${i}`} nft={nft} index={i} size="compact" />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : isSelectedMode && nftLoading ? (
          /* ════ LOADING STATE ════ */
          <div className="grid lg:grid-cols-5 gap-6 lg:gap-10">
            <div className="lg:col-span-3 space-y-6">
              <div className="aspect-square rounded-card shimmer" />
              <div className="rounded-card bg-surface2 border border-border-light p-6 space-y-3">
                <div className="h-8 w-2/3 rounded shimmer" />
                <div className="h-4 w-full rounded shimmer" />
                <div className="h-4 w-3/4 rounded shimmer" />
              </div>
            </div>
            <div className="lg:col-span-2">
              <div className="rounded-card bg-surface2 border border-border-light p-6 space-y-4">
                <div className="h-6 w-1/2 rounded shimmer" />
                <div className="h-4 w-3/4 rounded shimmer" />
                <div className="h-12 rounded-pill shimmer" />
              </div>
            </div>
          </div>
        ) : (
          /* ════ GENERIC COLLECTION MINT MODE ════ */
          <div className="space-y-12">
            {/* Generic Hero */}
            <div className="text-center max-w-2xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-pill bg-accent/10 border border-accent/20 mb-6">
                <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                <span className="text-xs font-display font-semibold text-accent uppercase tracking-wider">
                  Minting Open
                </span>
              </div>
              <h1 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl mb-4">
                Mint from the{" "}
                <span className="text-gradient">Aurora Collection</span>
              </h1>
              <p className="text-muted text-base sm:text-lg leading-relaxed">
                Browse the full collection below and click any NFT to view details and mint it.
              </p>
            </div>

            {/* Quick mint panel (generic) */}
            <div className="max-w-md mx-auto">
              <MintPanel
                siteSettings={settings}
                loading={settingsLoading}
                isMintable={true}
              />
            </div>

            {/* Full collection grid */}
            <div>
              <h2 className="font-display font-bold text-xl sm:text-2xl mb-6">
                Choose Your NFT
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-5">
                {relatedLoading ? (
                  <NftCardSkeleton count={10} />
                ) : relatedNfts.length > 0 ? (
                  relatedNfts.map((nft, i) => (
                    <NftCard key={`grid-${nft.contractAddress}-${nft.tokenId}-${i}`} nft={nft} index={i} />
                  ))
                ) : (
                  <NftCardSkeleton count={10} />
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Wrap in Suspense for useSearchParams
export default function MintPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-accent border-t-transparent rounded-full animate-spin" />
        </div>
      }
    >
      <MintPageContent />
    </Suspense>
  );
}
