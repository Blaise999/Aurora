"use client";
import HeroSection from "@/components/HeroSection";
import TrendingBar from "@/components/TrendingBar";
import FeaturedSection from "@/components/FeaturedSection";
import CollectionPreview from "@/components/CollectionPreview";
import MintCTA from "@/components/MintCTA";

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <TrendingBar />
      <FeaturedSection />
      <CollectionPreview />
      <MintCTA />
    </>
  );
}
