"use client";
import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useWallet } from "@/context/WalletContext";
import { shortenAddress } from "@/lib/utils";

export default function Navbar() {
  const { address, isConnected, connecting, connect, disconnect } = useWallet();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLinks = [
    { label: "Home", href: "/" },
    { label: "Explore", href: "/explore" },
    { label: "Mint", href: "/mint" },
    { label: "Profile", href: "/profile" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo — uses /logo.png only, no placeholder */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative w-9 h-9 sm:w-11 sm:h-11">
              <Image
                src="/logo.png"
                alt="Aurora NFT"
                fill
                className="object-contain drop-shadow-[0_0_8px_rgba(0,229,255,0.3)] group-hover:drop-shadow-[0_0_14px_rgba(0,229,255,0.5)] transition-all"
                priority
              />
            </div>
            <span className="font-display font-bold text-lg sm:text-xl tracking-tight text-gradient">
              Aurora
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-2 text-sm font-medium text-muted hover:text-text transition-colors rounded-pill hover:bg-white/5"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Wallet + Mobile Toggle */}
          <div className="flex items-center gap-3">
            <button
              onClick={isConnected ? disconnect : connect}
              disabled={connecting}
              className="relative px-5 py-2.5 rounded-pill text-sm font-semibold font-display transition-all duration-300 overflow-hidden group"
              style={{
                background: isConnected
                  ? "rgba(0, 229, 255, 0.1)"
                  : "linear-gradient(135deg, #00E5FF, #8B5CF6)",
                border: isConnected ? "1px solid rgba(0, 229, 255, 0.3)" : "none",
              }}
            >
              <span className="relative z-10">
                {connecting
                  ? "Connecting..."
                  : isConnected
                  ? shortenAddress(address)
                  : "Connect Wallet"}
              </span>
              {!isConnected && (
                <div className="absolute inset-0 bg-gradient-to-r from-accent-violet to-accent opacity-0 group-hover:opacity-100 transition-opacity" />
              )}
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden flex flex-col gap-1.5 p-2"
              aria-label="Menu"
            >
              <span className={`w-5 h-0.5 bg-text transition-all ${mobileOpen ? "rotate-45 translate-y-2" : ""}`} />
              <span className={`w-5 h-0.5 bg-text transition-all ${mobileOpen ? "opacity-0" : ""}`} />
              <span className={`w-5 h-0.5 bg-text transition-all ${mobileOpen ? "-rotate-45 -translate-y-2" : ""}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown */}
      {mobileOpen && (
        <div className="md:hidden glass-strong border-t border-border-light">
          <div className="px-4 py-4 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="block px-4 py-3 rounded-card text-sm font-medium text-muted hover:text-text hover:bg-white/5 transition"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
