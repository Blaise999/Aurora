'use client';
import { memo, useState } from 'react';
import Link from 'next/link';
import { Heart } from 'lucide-react';
import NFTMedia from './NFTMedia';
import Badge from '@/components/ui/Badge';

const NFTCard = memo(function NFTCard({ nft, index = 0 }) {
  const [isHovered, setIsHovered] = useState(false);
  const hasPrice = nft.price && nft.price !== '—';
  const hasLastSale = nft.lastSale && nft.lastSale !== '—';

  const detailHref =
    nft.contractAddress && nft.tokenId
      ? `/nft/${nft.contractAddress}/${nft.tokenId}`
      : `/nft/${nft.id}`;

  return (
    <Link href={detailHref} prefetch={false}>
      <div
        className="group rounded-card overflow-hidden bg-white/[0.02] border border-white/[0.06] hover:border-white/[0.10] transition-all duration-400 animate-fade-in"
        style={{ animationDelay: `${Math.min(index, 11) * 60}ms` }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="relative overflow-hidden">
          <div className={`transition-transform duration-700 ease-out ${isHovered ? 'scale-[1.04]' : 'scale-100'}`}>
            <NFTMedia src={nft.normalized_metadata?.image} alt={nft.name} hasVideo={nft.hasMedia && index % 7 === 0} />
          </div>
          <div className={`absolute inset-0 bg-gradient-to-t from-bg/80 via-transparent to-transparent transition-opacity duration-300 flex items-end p-4 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
            <span className="text-xs text-accent font-mono">View Details →</span>
          </div>
          <div className="absolute top-3 left-3">
            <Badge color="default" className="!bg-black/50 backdrop-blur-md !border-white/10 !text-[10px]">{nft.chain}</Badge>
          </div>
          <button
            className={`absolute top-3 right-3 w-8 h-8 rounded-full bg-black/30 backdrop-blur-md border border-white/10 flex items-center justify-center transition-all duration-300 hover:bg-white/10 ${isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-1'}`}
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
          >
            <Heart size={13} className="text-muted" />
          </button>
        </div>
        <div className="p-4 space-y-2">
          <p className="text-[10px] text-muted-dim font-mono truncate tracking-wide uppercase">{nft.collectionName}</p>
          <p className="text-sm font-display font-semibold text-text truncate group-hover:text-accent transition-colors duration-200">{nft.name}</p>
          {hasPrice || hasLastSale ? (
            <div className="flex items-center justify-between pt-2 border-t border-white/[0.06]">
              <div>
                <p className="text-[9px] text-muted-dim uppercase tracking-wider">Price</p>
                <p className="text-sm text-accent font-mono font-semibold mt-0.5">{nft.price}</p>
              </div>
              <div className="text-right">
                <p className="text-[9px] text-muted-dim uppercase tracking-wider">Last</p>
                <p className="text-sm text-muted font-mono mt-0.5">{nft.lastSale}</p>
              </div>
            </div>
          ) : (
            <div className="pt-2 border-t border-white/[0.06]">
              <p className="text-[10px] text-muted-dim/60 italic">No listing data</p>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
});

export default NFTCard;
