'use client';
import { useRef, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, ArrowUpRight } from 'lucide-react';
import Link from 'next/link';
import NFTCard from '@/components/nft/NFTCard';
import { featuredNFTs } from '@/lib/mock/nfts';
import { normalizeUiNfts } from '@/components/nft/normalizeUiNft';

export default function FeaturedNFTs() {
  const scrollRef = useRef(null);
  const nfts = useMemo(() => normalizeUiNfts(featuredNFTs), []);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkScroll = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setCanScrollLeft(scrollLeft > 10);
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
  };

  const scroll = (dir) => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({ left: dir * 320, behavior: 'smooth' });
    setTimeout(checkScroll, 400);
  };

  return (
    <section className="py-20 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 md:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-text">Featured</h2>
            <p className="text-[13px] text-muted mt-1">Hand-picked pieces from top collections</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex gap-1.5">
              <button
                onClick={() => scroll(-1)}
                disabled={!canScrollLeft}
                className="w-9 h-9 rounded-xl bg-white/[0.04] border border-white/[0.06] flex items-center justify-center text-muted hover:text-text hover:border-white/[0.10] transition-all duration-200 disabled:opacity-30 disabled:cursor-default"
              >
                <ChevronLeft size={16} />
              </button>
              <button
                onClick={() => scroll(1)}
                disabled={!canScrollRight}
                className="w-9 h-9 rounded-xl bg-white/[0.04] border border-white/[0.06] flex items-center justify-center text-muted hover:text-text hover:border-white/[0.10] transition-all duration-200 disabled:opacity-30 disabled:cursor-default"
              >
                <ChevronRight size={16} />
              </button>
            </div>
            <Link href="/explore" className="hidden sm:flex items-center gap-1 text-[13px] text-muted hover:text-accent transition-colors">
              See all <ArrowUpRight size={13} />
            </Link>
          </div>
        </div>
      </div>
      <div
        ref={scrollRef}
        onScroll={checkScroll}
        className="flex gap-5 overflow-x-auto scrollbar-hide px-6 md:px-8 snap-x snap-mandatory pb-4"
        style={{ scrollbarWidth: 'none' }}
      >
        <div className="shrink-0 w-[calc((100%-1400px)/2+1.5rem)] hidden xl:block" />
        {nfts.map((nft, i) => (
          <div key={nft.id} className="shrink-0 w-[280px] snap-start">
            <NFTCard nft={nft} index={i} />
          </div>
        ))}
        <div className="shrink-0 w-8" />
      </div>
    </section>
  );
}
