'use client';
import { ArrowUpRight } from 'lucide-react';
import Link from 'next/link';
import CollectionCard from '@/components/nft/CollectionCard';
import { mockCollections } from '@/lib/mock/collections';

export default function TrendingCollections() {
  return (
    <section className="py-20">
      <div className="max-w-[1400px] mx-auto px-6 md:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-text">Trending Collections</h2>
            <p className="text-[13px] text-muted mt-1">Most active in the last 24 hours</p>
          </div>
          <Link href="/explore" className="hidden sm:flex items-center gap-1 text-[13px] text-muted hover:text-accent transition-colors group">
            See all <ArrowUpRight size={13} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {mockCollections.map((col, i) => (
            <CollectionCard key={col.id} collection={col} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
