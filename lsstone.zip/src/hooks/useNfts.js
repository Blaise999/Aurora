"use client";
import { useState, useEffect } from "react";
import { LOCAL_NFTS } from "@/lib/constants";
import { shuffle } from "@/lib/utils";

// Fetch NFTs with API fallback to local
export function useNfts(endpoint, fallbackCount = 12) {
  const [nfts, setNfts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        const res = await fetch(endpoint);
        if (!res.ok) throw new Error("API failed");
        const data = await res.json();
        if (!cancelled && data.nfts?.length > 0) {
          setNfts(data.nfts);
        } else {
          // Fallback to local
          setNfts(shuffle(LOCAL_NFTS).slice(0, fallbackCount));
        }
      } catch (err) {
        if (!cancelled) {
          setError(err.message);
          setNfts(shuffle(LOCAL_NFTS).slice(0, fallbackCount));
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [endpoint, fallbackCount]);

  return { nfts, loading, error };
}

// Fetch trending NFTs
export function useTrendingNfts(limit = 12) {
  return useNfts(`/api/nft/trending?limit=${limit}`, limit);
}

// Fetch collection NFTs
export function useCollectionNfts(contractAddress, limit = 20) {
  return useNfts(
    `/api/nft/collection?contract=${contractAddress || ""}&limit=${limit}`,
    limit
  );
}

// Fetch wallet NFTs (on-chain via Alchemy)
export function useWalletNfts(walletAddress) {
  const [nfts, setNfts] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!walletAddress) return;
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        const res = await fetch(`/api/nft/owner?wallet=${walletAddress}`);
        const data = await res.json();
        if (!cancelled) setNfts(data.nfts || []);
      } catch {
        if (!cancelled) setNfts([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [walletAddress]);

  return { nfts, loading };
}

// Fetch DB-minted NFTs
export function useDbNfts(walletAddress) {
  const [nfts, setNfts] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!walletAddress) return;
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        const res = await fetch(`/api/nft/mint-record?wallet=${walletAddress}`);
        const data = await res.json();
        if (!cancelled) setNfts(data.nfts || []);
      } catch {
        if (!cancelled) setNfts([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [walletAddress]);

  return { nfts, loading };
}

// Fetch site settings
export function useSettings() {
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const res = await fetch("/api/settings");
        const data = await res.json();
        if (!cancelled) setSettings(data);
      } catch {
        if (!cancelled) setSettings({
          minting_fee: "0.002",
          buy_fee: "0.002",
          sale_active: "true",
          max_per_wallet: "10",
          treasury_wallet: "",
          contract_address: "",
        });
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  return { settings, loading };
}

// Fetch single NFT metadata
export function useNftMetadata(contractAddress, tokenId, nftId) {
  const [nft, setNft] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        // Try local first if nftId matches
        if (nftId && !contractAddress) {
          const local = LOCAL_NFTS.find((n) => n.nftId === nftId);
          if (local) {
            // Fetch price from DB
            const priceRes = await fetch(`/api/nft/metadata?nftId=${nftId}`);
            const priceData = await priceRes.json();
            if (!cancelled) setNft({ ...local, ...priceData.nft });
            return;
          }
        }
        // Fetch from API
        const params = new URLSearchParams();
        if (contractAddress) params.set("contract", contractAddress);
        if (tokenId) params.set("tokenId", tokenId);
        if (nftId) params.set("nftId", nftId);
        const res = await fetch(`/api/nft/metadata?${params.toString()}`);
        const data = await res.json();
        if (!cancelled && data.nft) setNft(data.nft);
      } catch {
        // Fallback to local NFT
        if (!cancelled && nftId) {
          const local = LOCAL_NFTS.find((n) => n.nftId === nftId);
          if (local) setNft(local);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [contractAddress, tokenId, nftId]);

  return { nft, loading };
}
