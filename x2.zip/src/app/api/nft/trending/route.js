import { NextResponse } from 'next/server';

// Mock trending data — replace with real DB/API call later
const trendingNfts = Array.from({ length: 8 }, (_, i) => {
  const id = i + 6; // offset to get different NFTs from featured
  const names = [
    'Nebula Core', 'Phantom Signal', 'Astral Prism', 'Dark Matter Bloom',
    'Ether Cascade', 'Mythic Shard', 'Genesis Pulse', 'Shadow Lattice',
  ];
  const collections = [
    'Quantum Garden', 'Void Walkers', 'Ethereal Voids', 'Chromatic Shift',
    'Neon Mythos', 'Digital Relics', 'Phantom Archive', 'Astral Drift',
  ];
  const chains = ['Ethereum', 'Polygon', 'Arbitrum', 'Base'];

  return {
    id: String(id),
    token_id: String(1000 + id),
    name: `${names[i % names.length]} #${1000 + id}`,
    normalized_metadata: {
      name: `${names[i % names.length]} #${1000 + id}`,
      image: `/pictures/nft-${String(id % 24).padStart(2, '0')}.svg`,
    },
    collectionName: collections[i % collections.length],
    chain: chains[i % chains.length],
    price: `${(0.1 + Math.random() * 2).toFixed(3)} ETH`,
    lastSale: `${(0.08 + Math.random() * 1.5).toFixed(3)} ETH`,
  };
});

export async function GET() {
  return NextResponse.json(
    { nfts: trendingNfts },
    {
      headers: {
        'Cache-Control': 'public, s-maxage=30, stale-while-revalidate=60',
      },
    }
  );
}
