import PageShell from '@/components/layout/PageShell';
import HeroCarousel from '@/components/hero/HeroCarousel';
import LiveStats from '@/components/home/LiveStats';
import BreakingNewsTicker from '@/components/home/BreakingNewsTicker';
import TrendingNftBar from '@/components/nft/TrendingNftBar';
import FeaturedNFTs from '@/components/home/FeaturedNFTs';
import TrendingCollections from '@/components/home/TrendingCollections';
import LiveDrops from '@/components/home/LiveDrops';
import TrustRow from '@/components/home/TrustRow';
import HowItWorks from '@/components/home/HowItWorks';
import MarketPulse from '@/components/home/MarketPulse';
import CallToAction from '@/components/home/CallToAction';
import Roadmap from '@/components/home/Roadmap';
import FAQ from '@/components/home/FAQ';

export default function Home() {
  return (
    <PageShell heroFused>
      {/* 1. Cinematic hero with carousel */}
      <HeroCarousel />

      {/* 2. Live stats bar (overlaps hero bottom) */}
      <LiveStats />

      {/* 3. Breaking news ticker */}
      <BreakingNewsTicker />

      {/* 4. Trending NFTs — 4 cards with motion */}
      <TrendingNftBar />

      {/* 5. Featured NFTs — horizontal scroll */}
      <FeaturedNFTs />

      {/* 6. Trending Collections — big cards grid */}
      <TrendingCollections />

      {/* 7. Live Drops — countdown + mint */}
      <LiveDrops />

      {/* 8. Trust signals */}
      <TrustRow />

      {/* 9. How it works */}
      <HowItWorks />

      {/* 10. Market Pulse — news */}
      <MarketPulse />

      {/* 11. CTA */}
      <CallToAction />

      {/* 12. Roadmap */}
      <Roadmap />

      {/* 13. FAQ */}
      <FAQ />
    </PageShell>
  );
}
