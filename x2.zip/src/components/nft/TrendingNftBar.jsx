'use client';
import { useState, useEffect, useMemo, useRef } from 'react';
import Link from 'next/link';
import { Flame, TrendingUp, ArrowUpRight, Heart, Eye } from 'lucide-react';
import NFTMedia from '@/components/nft/NFTMedia';
import Badge from '@/components/ui/Badge';
import { trendingNFTs, featuredNFTs } from '@/lib/mock/nfts';
import { normalizeUiNfts } from '@/components/nft/normalizeUiNft';

export default function TrendingNftBar() {
  const fallbackItems = useMemo(
    () => normalizeUiNfts(trendingNFTs.length ? trendingNFTs : featuredNFTs).slice(0, 4),
    []
  );
  const [items, setItems] = useState(fallbackItems);
  const [hoveredIdx, setHoveredIdx] = useState(-1);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  /* try live data, keep fallback */
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await fetch('/api/nft/trending');
        if (!res.ok) return;
        const data = await res.json();
        const list = normalizeUiNfts(data.nfts || data || []).slice(0, 4);
        if (alive && list.length >= 4) setItems(list);
      } catch { /* keep fallback */ }
    })();
    return () => { alive = false; };
  }, []);

  /* intersection observer for entrance animation */
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setIsVisible(true); },
      { threshold: 0.15 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  if (items.length === 0) return null;

  const rankLabels = ['#1', '#2', '#3', '#4'];
  const accentColors = [
    { ring: 'ring-accent/40', glow: 'shadow-[0_0_40px_rgba(0,229,255,0.12)]', badge: 'hot', tagBg: 'bg-accent/10 text-accent border-accent/20' },
    { ring: 'ring-accent-violet/40', glow: 'shadow-[0_0_40px_rgba(139,92,246,0.12)]', badge: 'rising', tagBg: 'bg-accent-violet/10 text-accent-violet border-accent-violet/20' },
    { ring: 'ring-success/40', glow: 'shadow-[0_0_40px_rgba(16,185,129,0.12)]', badge: 'success', tagBg: 'bg-success/10 text-success border-success/20' },
    { ring: 'ring-warning/40', glow: 'shadow-[0_0_40px_rgba(245,158,11,0.12)]', badge: 'warning', tagBg: 'bg-warning/10 text-warning border-warning/20' },
  ];

  return (
    <section ref={sectionRef} className="py-16 relative overflow-hidden">
      {/* Ambient background glow */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[500px] h-[300px] bg-accent/[0.03] rounded-full blur-[100px]" />
        <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-[400px] h-[250px] bg-accent-violet/[0.03] rounded-full blur-[100px]" />
      </div>

      <div className="max-w-[1400px] mx-auto px-6 md:px-8 relative">
        {/* Section header */}
        <div className="flex items-center justify-between mb-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-hot/20 to-hot/5 border border-hot/20 flex items-center justify-center">
              <Flame size={18} className="text-hot" />
            </div>
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-text">Trending Now</h2>
              <p className="text-xs text-muted-dim mt-0.5 font-mono tracking-wide">
                Top movers in the last 24h
              </p>
            </div>
          </div>
          <Link
            href="/explore"
            className="hidden sm:flex items-center gap-1.5 text-sm text-muted hover:text-accent transition-colors duration-200 group"
          >
            View all
            <ArrowUpRight size={14} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-200" />
          </Link>
        </div>

        {/* 4-card grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          {items.map((nft, i) => {
            const detailHref =
              nft.contractAddress && nft.tokenId
                ? `/nft/${nft.contractAddress}/${nft.tokenId}`
                : `/nft/${nft.id}`;
            const color = accentColors[i];
            const isHovered = hoveredIdx === i;
            const fakeChange = ['+42.3%', '+28.7%', '+19.1%', '+14.6%'][i];
            const fakeViews = [2847, 1923, 1456, 1102][i];

            return (
              <Link
                key={nft.id}
                href={detailHref}
                prefetch={false}
                onMouseEnter={() => setHoveredIdx(i)}
                onMouseLeave={() => setHoveredIdx(-1)}
              >
                <div
                  className={`
                    group relative rounded-card overflow-hidden
                    glass-card
                    transition-all duration-500 ease-out
                    ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}
                    ${isHovered ? `scale-[1.03] ${color.glow}` : 'scale-100'}
                  `}
                  style={{
                    transitionDelay: isVisible ? `${i * 100}ms` : '0ms',
                  }}
                >
                  {/* Rank badge */}
                  <div className="absolute top-3 left-3 z-20">
                    <div className={`
                      flex items-center gap-1 px-2 py-0.5 rounded-pill border text-[10px] font-mono font-bold
                      backdrop-blur-md ${color.tagBg}
                    `}>
                      <TrendingUp size={10} />
                      {rankLabels[i]}
                    </div>
                  </div>

                  {/* Quick actions on hover */}
                  <div className="absolute top-3 right-3 z-20 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button
                      className="w-7 h-7 rounded-full glass flex items-center justify-center hover:bg-white/10 transition-colors"
                      onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
                    >
                      <Heart size={12} className="text-muted" />
                    </button>
                  </div>

                  {/* NFT Image with zoom on hover */}
                  <div className="relative overflow-hidden">
                    <div className={`
                      transition-transform duration-700 ease-out
                      ${isHovered ? 'scale-[1.08]' : 'scale-100'}
                    `}>
                      <NFTMedia
                        src={nft.normalized_metadata?.image}
                        alt={nft.name}
                        aspect="portrait"
                        priority={i < 2}
                      />
                    </div>

                    {/* Gradient overlay */}
                    <div className={`
                      absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent
                      transition-opacity duration-500
                      ${isHovered ? 'opacity-100' : 'opacity-40'}
                    `} />

                    {/* Bottom info overlay */}
                    <div className={`
                      absolute bottom-0 inset-x-0 p-3 flex items-center justify-between
                      transition-all duration-500
                      ${isHovered ? 'translate-y-0 opacity-100' : 'translate-y-2 opacity-0'}
                    `}>
                      <div className="flex items-center gap-1.5 text-[10px] text-white/70 font-mono">
                        <Eye size={10} />
                        {fakeViews.toLocaleString()}
                      </div>
                      <Badge color={color.badge} className="!text-[9px] !px-2 !py-0 backdrop-blur-md">
                        {fakeChange}
                      </Badge>
                    </div>
                  </div>

                  {/* Card body */}
                  <div className="p-4 space-y-2.5">
                    <p className="text-[10px] text-muted-dim font-mono truncate tracking-wide uppercase">
                      {nft.collectionName}
                    </p>
                    <h3 className="font-display text-sm sm:text-[15px] font-semibold text-text truncate group-hover:text-accent transition-colors duration-300">
                      {nft.name}
                    </h3>

                    {/* Price row */}
                    <div className="flex items-center justify-between pt-2.5 border-t border-white/[0.06]">
                      <div>
                        <p className="text-[9px] text-muted-dim uppercase tracking-wider">Price</p>
                        <p className="text-sm text-accent font-mono font-semibold mt-0.5">
                          {nft.price !== '\u2014' ? nft.price : '0.42 ETH'}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-[9px] text-muted-dim uppercase tracking-wider">Last</p>
                        <p className="text-sm text-muted font-mono mt-0.5">
                          {nft.lastSale !== '\u2014' ? nft.lastSale : '0.38 ETH'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Accent ring on hover */}
                  <div className={`
                    absolute inset-0 rounded-card pointer-events-none
                    ring-1 ring-inset transition-all duration-500
                    ${isHovered ? color.ring : 'ring-transparent'}
                  `} />
                </div>
              </Link>
            );
          })}
        </div>

        {/* Mobile link */}
        <div className="sm:hidden mt-6 text-center">
          <Link
            href="/explore"
            className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-accent transition-colors duration-200"
          >
            View all trending
            <ArrowUpRight size={14} />
          </Link>
        </div>
      </div>
    </section>
  );
}
