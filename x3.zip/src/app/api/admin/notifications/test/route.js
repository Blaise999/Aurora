import { NextResponse } from 'next/server';
import { sendNtfyNotification } from '@/lib/ntfy';

/**
 * POST /api/admin/notifications/test
 * Sends a test push notification to the admin's phone via ntfy.
 */
export async function POST() {
  try {
    const ok = await sendNtfyNotification({
      title: '🧪 Test Notification',
      message: 'If you see this, ntfy is working correctly!\nTimestamp: ' + new Date().toISOString(),
      priority: 'default',
      tags: ['white_check_mark', 'bell'],
      click: '/admin',
    });

    if (!ok) {
      return NextResponse.json(
        { error: 'Ntfy request failed — check NTFY_SERVER and NTFY_TOPIC env vars' },
        { status: 502 }
      );
    }

    return NextResponse.json({ ok: true, message: 'Test notification sent' });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
