import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth/session";
import { getSupabase } from "@/lib/db/supabase";
import { sendNtfyNotification } from "@/lib/ntfy";

export const runtime = "nodejs";

/**
 * POST /api/nft/buy
 * Body: { txHash, nftId, contractAddress, tokenId, pricePaid }
 *
 * Called AFTER the user's wallet tx confirms on-chain.
 * The smart contract already collected buy_fee + nft_price and forwarded
 * them to the admin's treasury wallet.
 *
 * This endpoint:
 * 1. Verifies session (wallet must be connected + signed in)
 * 2. Saves the NFT purchase to user_nfts
 * 3. Caches metadata in nft_metadata_cache
 * 4. Sends ntfy notification to admin
 */
export async function POST(req: Request) {
  try {
    const wallet = await getSession();
    if (!wallet) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const body = await req.json();
    const { txHash, nftId, contractAddress, tokenId, pricePaid, name } = body;

    if (!txHash || !nftId) {
      return NextResponse.json(
        { error: "Missing txHash or nftId" },
        { status: 400 }
      );
    }

    const sb = getSupabase();
    const chainId = parseInt(process.env.NEXT_PUBLIC_CHAIN_ID || "84532", 10);
    const addr = (contractAddress || process.env.NEXT_PUBLIC_AURORA_CONTRACT || "").toLowerCase();
    const tid = tokenId || nftId;

    // Upsert into user_nfts
    const { error: nftErr } = await sb.from("user_nfts").upsert(
      {
        chain_id: chainId,
        contract_address: addr,
        token_id: tid,
        owner_address: wallet.toLowerCase(),
        minter_address: wallet.toLowerCase(),
        tx_hash: txHash.toLowerCase(),
        minted_at: new Date().toISOString(),
        status: "confirmed",
      },
      { onConflict: "chain_id,contract_address,token_id" }
    );
    if (nftErr) {
      // If unique constraint on tx_hash fires, still treat as success (idempotent)
      if (!nftErr.message?.includes("duplicate")) throw nftErr;
    }

    // Upsert metadata cache
    await sb.from("nft_metadata_cache").upsert(
      {
        chain_id: chainId,
        contract_address: addr,
        token_id: tid,
        name: name || `NFT #${tid}`,
        description: "Purchased via AuroraNft",
        updated_at: new Date().toISOString(),
      },
      { onConflict: "chain_id,contract_address,token_id" }
    );

    // Log admin notification in DB
    await sb.from("admin_notifications").insert({
      type: "mint",
      title: "New Purchase!",
      body: `NFT #${tid} bought by ${wallet.slice(0, 8)}… for ${pricePaid || "?"} ETH`,
      metadata: { txHash, nftId, wallet, pricePaid },
    });

    // Push ntfy notification to admin phone
    await sendNtfyNotification({
      title: "💰 New NFT Purchase!",
      message: `NFT #${tid} bought by ${wallet}\nPrice: ${pricePaid || "?"} ETH\nTx: ${txHash}`,
      priority: "high",
      tags: ["money_with_wings", "tada"],
      click: "/admin",
    });

    return NextResponse.json({
      ok: true,
      tokenId: tid,
      txHash,
    });
  } catch (e: any) {
    console.error("[/api/nft/buy]", e);
    return NextResponse.json(
      { error: e?.message || "Failed" },
      { status: 500 }
    );
  }
}
