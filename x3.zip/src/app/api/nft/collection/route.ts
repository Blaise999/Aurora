import { NextResponse } from "next/server";
import { alchemyGet } from "@/lib/alchemy/nft";
import { alchemyOwnedToUi } from "@/lib/alchemy/nft-normalize";
import { defaultChainId } from "@/lib/alchemy/chains";

export const runtime = "nodejs";

/**
 * GET /api/nft/collection?contractAddress=0x...&startToken=...&chainId=8453
 *
 * Returns all NFTs in a collection with metadata (Alchemy getNFTsForContract v3).
 */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const contractAddress = searchParams.get("contractAddress") || "";
    const startToken = searchParams.get("startToken") || undefined;
    const chainId = parseInt(
      searchParams.get("chainId") || String(defaultChainId()),
      10
    );

    if (!contractAddress) {
      return NextResponse.json(
        { error: "Missing contractAddress" },
        { status: 400 }
      );
    }

    // Alchemy v3: getNFTsForContract (renamed from getNFTsForCollection)
    const payload = await alchemyGet(
      "getNFTsForContract",
      {
        contractAddress,
        withMetadata: "true",
        startToken,
        limit: "50",
      },
      chainId
    );

    return NextResponse.json({
      nfts: payload?.nfts ?? [],
      nextToken: payload?.nextToken ?? null,
    });
  } catch (e: any) {
    console.error("[/api/nft/collection]", e);
    return NextResponse.json(
      { error: e?.message || "Failed" },
      { status: 500 }
    );
  }
}
