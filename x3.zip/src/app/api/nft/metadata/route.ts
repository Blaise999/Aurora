import { NextResponse } from "next/server";
import { alchemyGet, normalizeSingleNft } from "@/lib/alchemy/nft";
import { defaultChainId } from "@/lib/alchemy/chains";

export const runtime = "nodejs";

/**
 * GET /api/nft/metadata?contractAddress=0x...&tokenId=123&chainId=8453
 *
 * Returns full metadata for a single NFT (Alchemy getNFTMetadata v3).
 * Also merges price/fee data from Supabase nft_prices table.
 */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const contractAddress = searchParams.get("contractAddress") || "";
    const tokenId = searchParams.get("tokenId") || "";
    const refreshCache = searchParams.get("refreshCache") || undefined;
    const chainId = parseInt(
      searchParams.get("chainId") || String(defaultChainId()),
      10
    );

    if (!contractAddress || !tokenId) {
      return NextResponse.json(
        { error: "Missing contractAddress or tokenId" },
        { status: 400 }
      );
    }

    const payload = await alchemyGet(
      "getNFTMetadata",
      { contractAddress, tokenId, refreshCache },
      chainId
    );

    const nft = normalizeSingleNft(payload);

    // Try to get price data from DB (non-blocking)
    let priceData = null;
    try {
      const { getSupabase } = await import("@/lib/db/supabase");
      const sb = getSupabase();
      const { data } = await sb
        .from("nft_prices")
        .select("price_eth, minting_fee_eth, is_listed")
        .eq("nft_id", tokenId)
        .maybeSingle();
      if (data) priceData = data;
    } catch {
      // DB not configured or table missing — continue without prices
    }

    return NextResponse.json({
      nft,
      pricing: priceData,
    });
  } catch (e: any) {
    console.error("[/api/nft/metadata]", e);
    return NextResponse.json(
      { error: e?.message || "Failed" },
      { status: 500 }
    );
  }
}
