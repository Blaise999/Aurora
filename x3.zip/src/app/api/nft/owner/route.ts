import { NextResponse } from "next/server";
import { alchemyGet } from "@/lib/alchemy/nft";
import { alchemyOwnedToUi } from "@/lib/alchemy/nft-normalize";
import { defaultChainId } from "@/lib/alchemy/chains";

export const runtime = "nodejs";

/**
 * GET /api/nft/owner?owner=0x...&chainId=8453&pageKey=...
 *
 * Returns ALL NFTs the wallet owns across the chain (Alchemy getNFTsForOwner v3).
 * Chain is resolved dynamically from the chainId query param.
 * Alchemy key stays server-side.
 */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const owner = searchParams.get("owner") || "";
    const pageKey = searchParams.get("pageKey") || undefined;
    const chainId = parseInt(
      searchParams.get("chainId") || String(defaultChainId()),
      10
    );

    if (!owner) {
      return NextResponse.json({ error: "Missing owner" }, { status: 400 });
    }

    // Alchemy NFT API v3 — getNFTsForOwner
    // Docs: https://docs.alchemy.com/reference/getnftsforowner-v3
    const payload = await alchemyGet(
      "getNFTsForOwner",
      {
        owner,
        withMetadata: "true",
        pageSize: "50",
        pageKey,
        // Exclude spam if on a supported chain (paid tier)
        // excludeFilters: "SPAM",
      },
      chainId
    );

    return NextResponse.json({
      nfts: alchemyOwnedToUi(payload, chainId),
      pageKey: payload?.pageKey ?? null,
      totalCount: payload?.totalCount ?? null,
    });
  } catch (e: any) {
    console.error("[/api/nft/owner]", e);
    return NextResponse.json(
      { error: e?.message || "Failed" },
      { status: 500 }
    );
  }
}
