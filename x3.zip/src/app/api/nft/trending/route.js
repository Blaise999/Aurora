import { NextResponse } from "next/server";
import { fetchTrendingNfts } from "@/lib/alchemy";
import { LOCAL_NFTS } from "@/lib/constants";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const limit = parseInt(searchParams.get("limit") || "12");

  try {
    const nfts = await fetchTrendingNfts(limit);
    if (nfts.length > 0) {
      return NextResponse.json({ nfts, source: "alchemy" });
    }
    // Fallback to local NFTs
    const shuffled = [...LOCAL_NFTS].sort(() => Math.random() - 0.5).slice(0, limit);
    return NextResponse.json({ nfts: shuffled, source: "local" });
  } catch (err) {
    const shuffled = [...LOCAL_NFTS].sort(() => Math.random() - 0.5).slice(0, limit);
    return NextResponse.json({ nfts: shuffled, source: "fallback" });
  }
}
