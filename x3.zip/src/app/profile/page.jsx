"use client";
import { useState, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { useWallet } from "@/context/WalletContext";
import { useWalletNfts, useDbNfts } from "@/hooks/useNfts";
import { shortenAddress, dedupeNfts, resolveImage } from "@/lib/utils";
import NftCard from "@/components/NftCard";
import NftCardSkeleton from "@/components/NftCardSkeleton";

const TABS = [
  { key: "all", label: "All NFTs" },
  { key: "chain", label: "On-chain" },
  { key: "minted", label: "Minted on Aurora" },
];

export default function ProfilePage() {
  const { address, isConnected, connect } = useWallet();
  const [activeTab, setActiveTab] = useState("all");

  // Fetch on-chain NFTs from Alchemy
  const { nfts: chainNfts, loading: chainLoading } = useWalletNfts(address);

  // Fetch DB-minted NFTs
  const { nfts: dbNfts, loading: dbLoading } = useDbNfts(address);

  const isLoading = chainLoading || dbLoading;

  // Merge and dedupe — chain NFTs + DB NFTs
  const allNfts = useMemo(() => {
    const merged = [
      ...chainNfts.map((n) => ({ ...n, source: n.source || "chain" })),
      ...dbNfts.map((n) => ({ ...n, source: "database" })),
    ];
    return dedupeNfts(merged);
  }, [chainNfts, dbNfts]);

  // Filter by tab
  const filteredNfts = useMemo(() => {
    if (activeTab === "chain") return allNfts.filter((n) => n.source === "chain" || n.source === "alchemy");
    if (activeTab === "minted") return allNfts.filter((n) => n.source === "database");
    return allNfts;
  }, [allNfts, activeTab]);

  // Not connected state
  if (!isConnected) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-surface2 border border-border-light flex items-center justify-center">
            <svg className="w-8 h-8 text-muted-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 12a2.25 2.25 0 00-2.25-2.25H15a3 3 0 11-6 0H5.25A2.25 2.25 0 003 12m18 0v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6m18 0V9M3 12V9m18 0a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 9m18 0V6a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v3" />
            </svg>
          </div>
          <h2 className="font-display font-bold text-2xl mb-3">Connect Your Wallet</h2>
          <p className="text-muted text-sm mb-6 leading-relaxed">
            Connect your wallet to view your NFT collection — including NFTs minted on other
            platforms and those purchased through Aurora.
          </p>
          <button
            onClick={connect}
            className="px-8 py-3.5 rounded-pill font-display font-bold text-sm bg-gradient-to-r from-accent to-accent-violet text-bg hover:shadow-glow transition-all hover:scale-[1.02]"
          >
            Connect Wallet
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 right-1/4 w-[400px] h-[400px] bg-accent-violet/4 rounded-full blur-[180px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Profile Header */}
        <div className="rounded-card bg-surface2 border border-border-light overflow-hidden mb-8">
          {/* Banner */}
          <div className="h-32 sm:h-40 bg-gradient-to-r from-accent/10 via-accent-violet/10 to-accent/10 relative">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,rgba(0,229,255,0.1),transparent)]" />
          </div>

          <div className="px-5 sm:px-8 pb-6 -mt-10 sm:-mt-12 relative z-10">
            {/* Avatar */}
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-surface3 border-4 border-surface2 flex items-center justify-center">
              <span className="font-display font-bold text-xl sm:text-2xl text-gradient">
                {address?.slice(2, 4).toUpperCase()}
              </span>
            </div>

            <div className="mt-4 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
              <div>
                <h1 className="font-display font-bold text-xl sm:text-2xl">
                  {shortenAddress(address)}
                </h1>
                <p className="text-xs text-muted-dim font-mono mt-1">{address}</p>
              </div>

              <div className="flex gap-4 sm:gap-6">
                <div className="text-center">
                  <p className="font-display font-bold text-lg">{allNfts.length}</p>
                  <p className="text-xs text-muted-dim">Total NFTs</p>
                </div>
                <div className="text-center">
                  <p className="font-display font-bold text-lg">{chainNfts.length}</p>
                  <p className="text-xs text-muted-dim">On-chain</p>
                </div>
                <div className="text-center">
                  <p className="font-display font-bold text-lg">{dbNfts.length}</p>
                  <p className="text-xs text-muted-dim">Aurora Mints</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar pb-2">
          {TABS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`
                px-5 py-2.5 rounded-pill text-sm font-display font-medium whitespace-nowrap transition-all
                ${
                  activeTab === tab.key
                    ? "bg-accent/15 text-accent border border-accent/30"
                    : "bg-surface2 text-muted border border-border-light hover:border-border hover:text-text"
                }
              `}
            >
              {tab.label}
              <span className="ml-2 text-xs opacity-60">
                {tab.key === "all"
                  ? allNfts.length
                  : tab.key === "chain"
                  ? chainNfts.length
                  : dbNfts.length}
              </span>
            </button>
          ))}
        </div>

        {/* NFT Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-5">
            <NftCardSkeleton count={10} />
          </div>
        ) : filteredNfts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-5">
            {filteredNfts.map((nft, i) => (
              <div key={`${nft.contractAddress}-${nft.tokenId}-${i}`} className="relative">
                <NftCard nft={nft} index={i} />
                {/* Source badge */}
                <div
                  className={`
                    absolute top-2 right-2 z-10 px-2 py-0.5 rounded-pill text-[9px] font-semibold uppercase tracking-wider
                    ${
                      nft.source === "database"
                        ? "bg-success/20 text-success border border-success/30"
                        : "bg-accent/20 text-accent border border-accent/30"
                    }
                  `}
                >
                  {nft.source === "database" ? "Aurora" : "Chain"}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-surface2 border border-border-light flex items-center justify-center">
              <svg className="w-7 h-7 text-muted-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909M3.75 21h16.5a1.5 1.5 0 001.5-1.5V5.25a1.5 1.5 0 00-1.5-1.5H3.75a1.5 1.5 0 00-1.5 1.5V19.5a1.5 1.5 0 001.5 1.5z" />
              </svg>
            </div>
            <p className="text-muted font-medium mb-2">No NFTs found</p>
            <p className="text-sm text-muted-dim mb-6">Start your collection by minting an NFT</p>
            <Link
              href="/explore"
              className="inline-flex px-6 py-3 rounded-pill font-display font-semibold text-sm bg-gradient-to-r from-accent to-accent-violet text-bg hover:shadow-glow transition-all"
            >
              Explore NFTs
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
