"use client";
import Link from "next/link";
import Image from "next/image";

export default function Footer() {
  return (
    <footer className="border-t border-border-light bg-surface/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <Link href="/" className="flex items-center gap-3 mb-4">
              <div className="relative w-9 h-9">
                <Image src="/logo.png" alt="Aurora NFT" fill className="object-contain" />
              </div>
              <span className="font-display font-bold text-lg text-gradient">Aurora</span>
            </Link>
            <p className="text-sm text-muted-dim leading-relaxed max-w-xs">
              Discover, collect, and mint unique digital art on the blockchain.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display font-semibold text-sm uppercase tracking-wider text-muted mb-4">
              Explore
            </h4>
            <div className="space-y-2.5">
              {[
                { label: "Trending", href: "/explore" },
                { label: "Collections", href: "/explore" },
                { label: "Mint", href: "/mint" },
              ].map((link) => (
                <Link
                  key={link.label}
                  href={link.href}
                  className="block text-sm text-muted-dim hover:text-accent transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Account */}
          <div>
            <h4 className="font-display font-semibold text-sm uppercase tracking-wider text-muted mb-4">
              Account
            </h4>
            <div className="space-y-2.5">
              {[
                { label: "Profile", href: "/profile" },
                { label: "My NFTs", href: "/profile" },
              ].map((link) => (
                <Link
                  key={link.label}
                  href={link.href}
                  className="block text-sm text-muted-dim hover:text-accent transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Chain */}
          <div>
            <h4 className="font-display font-semibold text-sm uppercase tracking-wider text-muted mb-4">
              Network
            </h4>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-success shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
              <span className="text-sm text-muted-dim">Base Sepolia</span>
            </div>
            <p className="text-xs text-muted-dim/60">ERC-721 on Base L2</p>
          </div>
        </div>

        <div className="glow-line mt-10 mb-6" />

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-dim/50">
            &copy; {new Date().getFullYear()} Aurora NFT. All rights reserved.
          </p>
          <p className="text-xs text-muted-dim/40">Built on Base</p>
        </div>
      </div>
    </footer>
  );
}
