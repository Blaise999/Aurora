"use client";
import { useState } from "react";
import Image from "next/image";
import toast from "react-hot-toast";
import { useWallet } from "@/context/WalletContext";
import { mintFromContract, buyViaCollector, sendToTreasury } from "@/lib/contracts";
import { AURORA_CONTRACT, TREASURY_WALLET } from "@/lib/constants";
import { isAuroraNft, formatEth, shortenAddress, resolveImage } from "@/lib/utils";

export default function MintPanel({
  nft = null,
  pricing = null,
  siteSettings = null,
  loading = false,
  isMintable = false,
}) {
  const { address, isConnected, isWrongChain, connect, switchChain } = useWallet();
  const [quantity, setQuantity] = useState(1);
  const [minting, setMinting] = useState(false);
  const [txHash, setTxHash] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  // Pricing
  const priceEth = pricing?.price_eth || nft?.price_eth || siteSettings?.minting_fee || "0.002";
  const mintingFee = pricing?.minting_fee_eth || siteSettings?.minting_fee || "0.002";
  const totalPrice = (parseFloat(priceEth) + parseFloat(mintingFee)) * quantity;
  const treasuryAddress = siteSettings?.treasury_wallet || TREASURY_WALLET;

  // Check if this NFT can be minted from our Aurora contract
  const canMintFromContract = isMintable || isAuroraNft(nft, AURORA_CONTRACT);

  async function handleMint() {
    if (!isConnected) return connect();
    if (isWrongChain) return switchChain();

    setMinting(true);
    setError(null);
    setTxHash(null);
    setSuccess(false);

    const mintToast = toast.loading(
      canMintFromContract ? "Minting NFT..." : "Processing purchase..."
    );

    try {
      let result;

      if (canMintFromContract) {
        // Mode A: Mint from our Aurora contract
        result = await mintFromContract(quantity, priceEth);
      } else {
        // Mode B: External NFT — send payment to treasury via BuyCollector or direct
        try {
          result = await buyViaCollector(
            nft?.nftId || nft?.tokenId || "0",
            totalPrice.toFixed(6)
          );
        } catch {
          // Fallback: direct ETH transfer to treasury
          result = await sendToTreasury(totalPrice.toFixed(6), treasuryAddress);
        }
      }

      setTxHash(result.hash);
      setSuccess(true);

      toast.success(
        canMintFromContract
          ? `NFT minted successfully!`
          : `Purchase complete!`,
        { id: mintToast, duration: 6000 }
      );

      // Save to database
      await fetch("/api/nft/buy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contractAddress: nft?.contractAddress || AURORA_CONTRACT,
          tokenId: nft?.tokenId || "0",
          nftId: nft?.nftId || null,
          ownerAddress: address,
          minterAddress: address,
          txHash: result.hash,
          name: nft?.name || "Aurora NFT",
          description: nft?.description || "",
          imageUrl: nft?.image || resolveImage(nft),
          attributes: nft?.attributes || [],
          priceEth: totalPrice.toFixed(6),
          mintingFeeEth: mintingFee,
        }),
      });
    } catch (err) {
      const msg = err.reason || err.message || "Transaction failed";
      setError(msg);
      toast.error(msg, { id: mintToast });
    } finally {
      setMinting(false);
    }
  }

  if (loading) {
    return (
      <div className="rounded-card bg-surface2 border border-border-light p-6 space-y-4">
        <div className="h-6 w-1/2 rounded shimmer" />
        <div className="h-4 w-3/4 rounded shimmer" />
        <div className="h-12 rounded-pill shimmer" />
      </div>
    );
  }

  return (
    <div className="rounded-card bg-surface2 border border-border-light overflow-hidden">
      {/* Header */}
      <div className="px-5 sm:px-6 py-4 border-b border-border-light bg-surface3/30">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-bold text-base">
            {canMintFromContract ? "Mint NFT" : "Purchase NFT"}
          </h3>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
            <span className="text-xs text-success font-medium">
              {siteSettings?.sale_active === "true" ? "Sale Active" : "Sale Paused"}
            </span>
          </div>
        </div>
      </div>

      <div className="p-5 sm:p-6 space-y-5">
        {/* NFT mini preview when present */}
        {nft && nft.name && (
          <div className="flex items-center gap-3 p-3 rounded-xl bg-surface3/40 border border-border-light">
            <div className="relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 border border-border-light">
              <Image
                src={resolveImage(nft)}
                alt={nft.name}
                fill
                className="object-cover"
                sizes="48px"
              />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-display font-semibold truncate">{nft.name}</p>
              <p className="text-xs text-muted-dim truncate">
                {nft.collection || "Aurora Collection"}
              </p>
            </div>
          </div>
        )}

        {/* Price breakdown */}
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted">NFT Price</span>
            <span className="font-mono font-semibold">{formatEth(priceEth)} ETH</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted">Mint Fee</span>
            <span className="font-mono font-semibold">{formatEth(mintingFee)} ETH</span>
          </div>
          <div className="h-px bg-border-light" />
          <div className="flex justify-between text-sm">
            <span className="text-muted">Quantity</span>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-7 h-7 rounded-full border border-border flex items-center justify-center text-xs hover:border-accent transition"
                disabled={minting}
              >
                −
              </button>
              <span className="font-mono font-bold w-6 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity(Math.min(5, quantity + 1))}
                className="w-7 h-7 rounded-full border border-border flex items-center justify-center text-xs hover:border-accent transition"
                disabled={minting}
              >
                +
              </button>
            </div>
          </div>
          <div className="h-px bg-border-light" />
          <div className="flex justify-between">
            <span className="font-display font-semibold">Total</span>
            <span className="font-mono font-bold text-lg text-accent">
              {totalPrice.toFixed(4)} ETH
            </span>
          </div>
        </div>

        {/* CTA Button */}
        <button
          onClick={handleMint}
          disabled={minting || success}
          className={`
            w-full py-4 rounded-pill font-display font-bold text-sm transition-all duration-300
            ${
              success
                ? "bg-success/20 text-success border border-success/30"
                : minting
                ? "bg-surface3 text-muted cursor-wait"
                : !isConnected
                ? "bg-gradient-to-r from-accent to-accent-violet text-bg hover:shadow-glow hover:scale-[1.02]"
                : isWrongChain
                ? "bg-warning/20 text-warning border border-warning/30 hover:bg-warning/30"
                : "bg-gradient-to-r from-accent to-accent-violet text-bg hover:shadow-glow hover:scale-[1.02]"
            }
          `}
        >
          {success
            ? "✓ Minted Successfully!"
            : minting
            ? "Confirming Transaction..."
            : !isConnected
            ? "Connect Wallet"
            : isWrongChain
            ? "Switch to Base Network"
            : canMintFromContract
            ? `Mint for ${totalPrice.toFixed(4)} ETH`
            : `Purchase for ${totalPrice.toFixed(4)} ETH`}
        </button>

        {/* Wallet info */}
        {isConnected && (
          <div className="flex items-center gap-2 text-xs text-muted-dim">
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
            Connected: {shortenAddress(address)}
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="p-3 rounded-xl bg-danger/10 border border-danger/20 text-sm text-danger">
            {error}
          </div>
        )}

        {/* Success + TX link */}
        {success && txHash && (
          <div className="p-3 rounded-xl bg-success/10 border border-success/20">
            <p className="text-sm text-success font-medium mb-1">Transaction confirmed!</p>
            <a
              href={`https://sepolia.basescan.org/tx/${txHash}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-accent hover:underline break-all"
            >
              View on BaseScan →
            </a>
          </div>
        )}

        {/* Info note for external NFTs */}
        {!canMintFromContract && nft && (
          <p className="text-[11px] text-muted-dim/60 leading-relaxed">
            This NFT is from an external collection. Your payment will be processed and the NFT data
            will be saved to your Aurora profile.
          </p>
        )}
      </div>
    </div>
  );
}
