"use client";
import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { buildMintUrl, resolveImage, formatEth } from "@/lib/utils";

export default function NftCard({ nft, index = 0, size = "default" }) {
  const [imgError, setImgError] = useState(false);
  const [hovered, setHovered] = useState(false);

  const image = imgError ? "/pictures/nft-00.svg" : resolveImage(nft);
  const mintUrl = buildMintUrl(nft);
  const price = nft.price_eth || nft.priceEth || null;

  const isCompact = size === "compact";
  const isLarge = size === "large";

  return (
    <Link
      href={mintUrl}
      className={`
        block group relative card-hover rounded-card overflow-hidden
        bg-surface border border-border-light
        ${isCompact ? "max-w-[180px]" : isLarge ? "" : ""}
      `}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ animationDelay: `${index * 80}ms` }}
    >
      {/* Image container */}
      <div className={`relative overflow-hidden ${isCompact ? "aspect-square" : "aspect-[4/5]"}`}>
        <Image
          src={image}
          alt={nft.name || "NFT"}
          fill
          className={`
            object-cover transition-transform duration-700
            ${hovered ? "scale-110" : "scale-100"}
          `}
          onError={() => setImgError(true)}
          sizes={isCompact ? "180px" : "(max-width:640px) 50vw, (max-width:1024px) 33vw, 25vw"}
        />

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent opacity-80" />

        {/* Hover overlay */}
        <div
          className={`
            absolute inset-0 bg-gradient-to-t from-accent/10 via-transparent to-transparent
            transition-opacity duration-300
            ${hovered ? "opacity-100" : "opacity-0"}
          `}
        />

        {/* Mint badge */}
        <div
          className={`
            absolute top-3 right-3 px-3 py-1 rounded-pill text-xs font-semibold font-display
            bg-accent/20 text-accent border border-accent/30 backdrop-blur-sm
            transition-all duration-300
            ${hovered ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-2"}
          `}
        >
          Mint
        </div>

        {/* Collection badge */}
        {nft.collection && !isCompact && (
          <div className="absolute top-3 left-3 px-2.5 py-1 rounded-pill text-[10px] font-medium bg-surface/80 text-muted backdrop-blur-sm border border-border-light">
            {nft.collection}
          </div>
        )}
      </div>

      {/* Info */}
      <div className={`p-3 ${isCompact ? "p-2.5" : "p-3 sm:p-4"}`}>
        <h3 className={`font-display font-semibold truncate ${isCompact ? "text-xs" : "text-sm"}`}>
          {nft.name || `NFT #${nft.tokenId}`}
        </h3>

        {!isCompact && (
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-muted-dim">
              {nft.source === "alchemy" ? "On-chain" : "Aurora"}
            </span>
            {price && (
              <span className="text-xs font-mono font-semibold text-accent">
                {formatEth(price)} ETH
              </span>
            )}
          </div>
        )}

        {isCompact && price && (
          <p className="text-[10px] font-mono text-accent mt-1">{formatEth(price)} ETH</p>
        )}
      </div>

      {/* Bottom glow line on hover */}
      <div
        className={`
          absolute bottom-0 left-0 right-0 h-[2px]
          bg-gradient-to-r from-transparent via-accent to-transparent
          transition-opacity duration-300
          ${hovered ? "opacity-100" : "opacity-0"}
        `}
      />
    </Link>
  );
}
